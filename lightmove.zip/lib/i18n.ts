// 다국어 지원 (한국어 / 영어)
// Light Move - i18n System

export type Language = 'ko' | 'en';

export const translations = {
  ko: {
    // 앱 공통
    appName: '라이트무브',
    appTagline: '체크인 전·후 반나절 여행 도우미',
    appSlogan: '체크인 전후 붕 뜨는 시간,\n무거운 짐 없이 더 가볍게 즐기세요.',
    dataNote: '※ 현재 샘플 데이터로 동작 중 (실제 공공데이터 API 연동 예정)',

    // 온보딩
    onboarding: {
      skip: '건너뛰기',
      start: '시작하기',
      slides: [
        {
          title: '짐 걱정 없이\n자유롭게',
          desc: '체크인 전·후 애매한 시간,\n짐 보관함을 찾아드립니다.',
          icon: '🧳',
        },
        {
          title: '편한 이동 경로\n안내',
          desc: '계단 없는 경로, 엘리베이터 우선\n짐 끌기 편한 길을 알려드려요.',
          icon: '🗺️',
        },
        {
          title: '딱 맞는\n반나절 코스',
          desc: '남은 시간에 맞춰\n최적의 관광 코스를 추천해드려요.',
          icon: '⏱️',
        },
      ],
    },

    // 상황 선택
    situation: {
      title: '지금 어떤 상황인가요?',
      subtitle: '상황에 맞는 맞춤 추천을 드립니다',
      checkinBefore: '체크인 전',
      checkinBeforeDesc: '숙소에 아직 체크인 못 했어요.\n짐을 맡기고 먼저 구경할게요.',
      checkoutAfter: '체크아웃 후',
      checkoutAfterDesc: '숙소에서 체크아웃 했어요.\n다음 일정 전까지 시간이 있어요.',
    },

    // 정보 입력
    input: {
      title: '여행 정보 입력',
      subtitle: '정확할수록 더 좋은 추천을 드려요',
      location: '현재 위치 / 도착역',
      locationPlaceholder: '역 또는 위치를 선택하세요',
      nextSchedule: '다음 일정',
      nextScheduleLabel: '체크인 시간 / 출발 시간',
      luggage: '짐 종류',
      luggageHint: '복수 선택 가능',
      movePrefer: '이동 선호',
      tourPrefer: '관광 선호',
      submit: '추천 받기',
      locations: ['서울역', '홍대입구역', '명동역'],
      luggageTypes: ['백팩', '기내용 캐리어', '24인치 캐리어', '28인치 캐리어', '쇼핑백', '선물상자'],
      movePrefers: ['계단 적은 경로', '엘리베이터 우선', '에스컬레이터 우선', '많이 걷지 않기'],
      tourPrefers: ['실내 위주', '사진 찍기 좋은 곳', '식사 포함', '짧게 산책', '쇼핑 포함'],
    },

    // 추천 결과
    result: {
      title: '추천 결과',
      aiSummary: 'AI 추천',
      freeTime: '자유시간',
      lockers: '추천 보관함',
      viewCourse: '반나절 코스 보기',
      selectLocker: '보관함 선택',
      viewRoute: '이동 경로 보기',
      available: '이용 가능',
      unavailable: '이용 불가',
      recommended: '추천',
      lockerSize: {
        small: '소형',
        medium: '중형',
        large: '대형',
      },
    },

    // 보관함 상세
    locker: {
      title: '보관함 상세',
      location: '위치',
      status: '현재 상태',
      size: '크기별 가용',
      fee: '예상 요금',
      travelTime: '이동 시간',
      returnEase: '복귀 편의성',
      reason: '추천 이유',
      selectBtn: '이 보관함 선택',
      reserveBtn: '예약 진행 (외부 연계 예정)',
      reserveNote: '※ 현재 예약 연계 데모 버전입니다. 실제 예약은 외부 서비스와 연동 예정입니다.',
      perHour: '원/시간',
      feeNote: '기준 요금 (실제 요금은 현장 확인)',
    },

    // 이동 경로
    route: {
      title: '이동 경로',
      shortest: '최단 경로',
      easiest: '짐 끌기 편한 경로',
      duration: '예상 시간',
      difficulty: '난이도',
      transfers: '환승',
      stairsAvoided: '계단 회피',
      elevator: '엘리베이터',
      escalator: '에스컬레이터',
      yes: '가능',
      no: '불가',
      times: '회',
      minutes: '분',
      easy: '쉬움',
      medium: '보통',
      hard: '힘듦',
    },

    // 반나절 코스
    course: {
      title: '반나절 코스 추천',
      subtitle: '남은 시간에 맞는 코스를 골라보세요',
      indoor: '실내',
      outdoor: '실외',
      duration: '예상 시간',
      difficulty: '이동 난이도',
      reason: '추천 이유',
      returnNote: '복귀 편의성',
      selectBtn: '이 코스 선택',
      minutes: '분',
      hours: '시간',
    },

    // 요약
    summary: {
      title: '내 여행 플랜',
      freeTime: '총 자유시간',
      locker: '추천 보관함',
      course: '추천 코스',
      returnTime: '복귀 시작 권장',
      returnNote: '이 시각까지 보관함으로 돌아오세요',
      restart: '다시 검색',
      share: '공유하기',
      timeline: '시간 계획',
      moveToLocker: '보관함 이동',
      storeLuggage: '짐 보관',
      freeTour: '자유 관광',
      returnLocker: '보관함 복귀',
      nextSchedule: '다음 일정',
    },

    // 설정
    settings: {
      title: '설정',
      language: '언어',
      timeFormat: '시간 표시',
      timeFormat12: '12시간제',
      timeFormat24: '24시간제',
      appInfo: '앱 정보',
      version: '버전',
      dataSource: '데이터 출처',
      dataSourceDetail: '공영 물품보관함 정보 (샘플 데이터)',
      dataStatus: '데이터 연동 상태',
      dataSample: '샘플 데이터 (데모)',
      dataReal: '실제 API 연동',
      about: '서비스 소개',
      aboutText: '라이트무브는 체크인 전·후 짐 보관 추천, 편한 이동 경로, 반나절 코스 추천을 한 번에 제공하는 여행 도우미 앱입니다.',
      publicDataContest: '공공데이터 공모전 제출용 데모',
    },

    // 탭바
    tabs: {
      home: '홈',
      lockers: '보관함',
      courses: '코스',
      settings: '설정',
    },

    // 공통
    common: {
      back: '뒤로',
      next: '다음',
      confirm: '확인',
      cancel: '취소',
      loading: '불러오는 중...',
      error: '오류가 발생했습니다',
      retry: '다시 시도',
      minutes: '분',
      hours: '시간',
      won: '원',
      free: '무료',
    },
  },

  en: {
    appName: 'Light Move',
    appTagline: 'Half-day travel guide before/after check-in',
    appSlogan: 'Make the most of your free time\nbetween check-in and check-out.',
    dataNote: '※ Running on sample data (real public API integration planned)',

    onboarding: {
      skip: 'Skip',
      start: 'Get Started',
      slides: [
        {
          title: 'Travel Light,\nWorry-Free',
          desc: 'Find luggage storage near you\nbefore or after check-in.',
          icon: '🧳',
        },
        {
          title: 'Luggage-Friendly\nRoutes',
          desc: 'Elevator-first, minimal stairs\nroutes for easy luggage travel.',
          icon: '🗺️',
        },
        {
          title: 'Perfect\nHalf-Day Plans',
          desc: 'Get tour recommendations\nfitted to your free time.',
          icon: '⏱️',
        },
      ],
    },

    situation: {
      title: "What's your situation?",
      subtitle: 'Get personalized recommendations',
      checkinBefore: 'Before Check-in',
      checkinBeforeDesc: "Haven't checked in yet.\nStore luggage and explore first.",
      checkoutAfter: 'After Check-out',
      checkoutAfterDesc: 'Already checked out.\nHave time before next schedule.',
    },

    input: {
      title: 'Travel Info',
      subtitle: 'More details = better recommendations',
      location: 'Current Location / Station',
      locationPlaceholder: 'Select a station or location',
      nextSchedule: 'Next Schedule',
      nextScheduleLabel: 'Check-in / Departure time',
      luggage: 'Luggage Type',
      luggageHint: 'Multiple selection allowed',
      movePrefer: 'Movement Preference',
      tourPrefer: 'Tour Preference',
      submit: 'Get Recommendations',
      locations: ['Seoul Station', 'Hongik Univ. Station', 'Myeongdong Station'],
      luggageTypes: ['Backpack', 'Carry-on', '24" Suitcase', '28" Suitcase', 'Shopping Bag', 'Gift Box'],
      movePrefers: ['Fewer Stairs', 'Elevator First', 'Escalator First', 'Minimal Walking'],
      tourPrefers: ['Mostly Indoor', 'Photo Spots', 'Include Meal', 'Short Walk', 'Shopping'],
    },

    result: {
      title: 'Recommendations',
      aiSummary: 'AI Summary',
      freeTime: 'Free Time',
      lockers: 'Recommended Lockers',
      viewCourse: 'View Half-Day Plans',
      selectLocker: 'Select Locker',
      viewRoute: 'View Route',
      available: 'Available',
      unavailable: 'Unavailable',
      recommended: 'Recommended',
      lockerSize: {
        small: 'Small',
        medium: 'Medium',
        large: 'Large',
      },
    },

    locker: {
      title: 'Locker Details',
      location: 'Location',
      status: 'Current Status',
      size: 'Size Availability',
      fee: 'Estimated Fee',
      travelTime: 'Travel Time',
      returnEase: 'Return Convenience',
      reason: 'Why Recommended',
      selectBtn: 'Select This Locker',
      reserveBtn: 'Reserve (External Link Planned)',
      reserveNote: '※ This is a demo reservation flow. Actual booking will be linked to external services.',
      perHour: 'KRW/hr',
      feeNote: 'Base rate (confirm actual fee on-site)',
    },

    route: {
      title: 'Route Details',
      shortest: 'Shortest Route',
      easiest: 'Luggage-Friendly Route',
      duration: 'Est. Time',
      difficulty: 'Difficulty',
      transfers: 'Transfers',
      stairsAvoided: 'Stairs Avoided',
      elevator: 'Elevator',
      escalator: 'Escalator',
      yes: 'Yes',
      no: 'No',
      times: '',
      minutes: 'min',
      easy: 'Easy',
      medium: 'Moderate',
      hard: 'Hard',
    },

    course: {
      title: 'Half-Day Plans',
      subtitle: 'Choose a plan that fits your time',
      indoor: 'Indoor',
      outdoor: 'Outdoor',
      duration: 'Est. Duration',
      difficulty: 'Travel Difficulty',
      reason: 'Why Recommended',
      returnNote: 'Return Convenience',
      selectBtn: 'Choose This Plan',
      minutes: 'min',
      hours: 'hr',
    },

    summary: {
      title: 'My Travel Plan',
      freeTime: 'Total Free Time',
      locker: 'Recommended Locker',
      course: 'Recommended Plan',
      returnTime: 'Suggested Return Time',
      returnNote: 'Return to locker by this time',
      restart: 'Search Again',
      share: 'Share',
      timeline: 'Timeline',
      moveToLocker: 'To Locker',
      storeLuggage: 'Store Luggage',
      freeTour: 'Free Tour',
      returnLocker: 'Return to Locker',
      nextSchedule: 'Next Schedule',
    },

    settings: {
      title: 'Settings',
      language: 'Language',
      timeFormat: 'Time Format',
      timeFormat12: '12-hour',
      timeFormat24: '24-hour',
      appInfo: 'App Info',
      version: 'Version',
      dataSource: 'Data Source',
      dataSourceDetail: 'Public Locker Info (Sample Data)',
      dataStatus: 'Data Integration Status',
      dataSample: 'Sample Data (Demo)',
      dataReal: 'Live API Connected',
      about: 'About',
      aboutText: 'Light Move is a travel assistant that provides luggage storage recommendations, luggage-friendly routes, and half-day tour plans all in one place.',
      publicDataContest: 'Public Data Contest Demo Submission',
    },

    tabs: {
      home: 'Home',
      lockers: 'Lockers',
      courses: 'Plans',
      settings: 'Settings',
    },

    common: {
      back: 'Back',
      next: 'Next',
      confirm: 'Confirm',
      cancel: 'Cancel',
      loading: 'Loading...',
      error: 'An error occurred',
      retry: 'Retry',
      minutes: 'min',
      hours: 'hr',
      won: 'KRW',
      free: 'Free',
    },
  },
} as const;

export type Translations = typeof translations.ko;
