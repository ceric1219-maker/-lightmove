// 라이트무브 샘플 데이터
// ※ 실제 공공데이터 API 연동 전 데모용 데이터입니다.
// 데이터 출처: 공공데이터포털 물품보관함 정보 (샘플/모의 데이터)

export type LockerSize = 'small' | 'medium' | 'large';
export type Difficulty = 'easy' | 'medium' | 'hard';
export type LuggageType = '백팩' | '기내용 캐리어' | '24인치 캐리어' | '28인치 캐리어' | '쇼핑백' | '선물상자';

export interface Locker {
  id: string;
  name: string;
  nameEn: string;
  zone: string; // 'seoul' | 'hongik' | 'myeongdong'
  location: string;
  locationEn: string;
  address: string;
  lat: number;
  lng: number;
  available: boolean;
  sizes: {
    small: boolean;
    medium: boolean;
    large: boolean;
  };
  feePerHour: {
    small: number;
    medium: number;
    large: number;
  };
  travelMinutes: number; // 현재 위치에서 이동 시간
  returnEase: 'good' | 'ok' | 'poor'; // 복귀 동선 편의성
  operatingHours: string;
  notes: string;
  notesEn: string;
}

export interface TouristSpot {
  id: string;
  name: string;
  nameEn: string;
  zone: string;
  category: string;
  categoryEn: string;
  indoor: boolean;
  durationMin: number; // 예상 체류시간 (분)
  distanceFromLocker: number; // 보관함에서 도보 거리 (분)
  tags: string[];
  tagsEn: string[];
  description: string;
  descriptionEn: string;
  imageEmoji: string;
}

export interface Course {
  id: string;
  name: string;
  nameEn: string;
  zone: string;
  totalMinutes: number;
  indoor: boolean;
  difficulty: Difficulty;
  spots: string[]; // TouristSpot IDs
  description: string;
  descriptionEn: string;
  returnConvenience: string;
  returnConvenienceEn: string;
  includesMeal: boolean;
  tags: string[];
}

export interface RouteOption {
  id: string;
  type: 'shortest' | 'easiest';
  from: string;
  to: string;
  durationMinutes: number;
  difficulty: Difficulty;
  transfers: number;
  stairsAvoided: boolean;
  elevatorAvailable: boolean;
  escalatorAvailable: boolean;
  steps: RouteStep[];
}

export interface RouteStep {
  type: 'walk' | 'subway' | 'transfer' | 'elevator' | 'escalator';
  description: string;
  descriptionEn: string;
  durationMinutes: number;
  icon: string;
}

// ===== 보관함 데이터 =====
export const lockers: Locker[] = [
  // 서울역 권역
  {
    id: 'seoul-1',
    name: '서울역 1층 물품보관함 (A구역)',
    nameEn: 'Seoul Station 1F Locker (Zone A)',
    zone: 'seoul',
    location: '서울역 1층 중앙 출구 근처',
    locationEn: 'Seoul Station 1F, near Central Exit',
    address: '서울특별시 용산구 한강대로 405',
    lat: 37.5547,
    lng: 126.9707,
    available: true,
    sizes: { small: true, medium: true, large: true },
    feePerHour: { small: 1000, medium: 2000, large: 3000 },
    travelMinutes: 3,
    returnEase: 'good',
    operatingHours: '05:30 - 23:30',
    notes: '대형 캐리어 보관 가능, 현재 위치에서 3분, 복귀 동선 유리',
    notesEn: 'Large luggage available, 3 min from current location, convenient return route',
  },
  {
    id: 'seoul-2',
    name: '서울역 지하 1층 코레일 보관함',
    nameEn: 'Seoul Station B1F Korail Locker',
    zone: 'seoul',
    location: '서울역 지하 1층 KTX 대합실',
    locationEn: 'Seoul Station B1F, KTX Waiting Hall',
    address: '서울특별시 용산구 한강대로 405',
    lat: 37.5545,
    lng: 126.9710,
    available: true,
    sizes: { small: true, medium: true, large: false },
    feePerHour: { small: 1000, medium: 2000, large: 0 },
    travelMinutes: 5,
    returnEase: 'good',
    operatingHours: '06:00 - 22:00',
    notes: '현재 가장 가깝지만 대형 캐리어 불가. KTX 탑승 동선과 연결 유리',
    notesEn: 'Closest option but no large luggage. Convenient for KTX boarding route',
  },
  {
    id: 'seoul-3',
    name: '서울역 버스환승센터 보관함',
    nameEn: 'Seoul Station Bus Terminal Locker',
    zone: 'seoul',
    location: '서울역 버스환승센터 2층',
    locationEn: 'Seoul Station Bus Terminal, 2F',
    address: '서울특별시 용산구 청파로 378',
    lat: 37.5542,
    lng: 126.9698,
    available: false,
    sizes: { small: true, medium: false, large: false },
    feePerHour: { small: 800, medium: 0, large: 0 },
    travelMinutes: 8,
    returnEase: 'ok',
    operatingHours: '07:00 - 21:00',
    notes: '현재 소형만 가능. 버스 이용 시 복귀 동선 양호',
    notesEn: 'Small only currently available. Good return route for bus users',
  },

  // 홍대입구역 권역
  {
    id: 'hongik-1',
    name: '홍대입구역 2번 출구 물품보관함',
    nameEn: 'Hongik Univ. Station Exit 2 Locker',
    zone: 'hongik',
    location: '홍대입구역 2번 출구 지하 1층',
    locationEn: 'Hongik Univ. Station Exit 2, B1F',
    address: '서울특별시 마포구 양화로 160',
    lat: 37.5572,
    lng: 126.9245,
    available: true,
    sizes: { small: true, medium: true, large: true },
    feePerHour: { small: 1000, medium: 2000, large: 3000 },
    travelMinutes: 4,
    returnEase: 'good',
    operatingHours: '06:00 - 24:00',
    notes: '대형 캐리어 보관 가능, 홍대 거리 접근 편리, 복귀 동선 우수',
    notesEn: 'Large luggage available, easy access to Hongdae area, excellent return route',
  },
  {
    id: 'hongik-2',
    name: '홍대입구역 9번 출구 공영보관함',
    nameEn: 'Hongik Univ. Station Exit 9 Public Locker',
    zone: 'hongik',
    location: '홍대입구역 9번 출구 인근 공영주차장',
    locationEn: 'Near Hongik Univ. Station Exit 9, Public Parking',
    address: '서울특별시 마포구 와우산로 21',
    lat: 37.5568,
    lng: 126.9252,
    available: true,
    sizes: { small: true, medium: true, large: false },
    feePerHour: { small: 800, medium: 1500, large: 0 },
    travelMinutes: 7,
    returnEase: 'ok',
    operatingHours: '07:00 - 22:00',
    notes: '공영 보관함으로 저렴. 대형 불가. 공항철도 탑승 시 복귀 동선 다소 불편',
    notesEn: 'Affordable public locker. No large luggage. Slightly inconvenient for AREX return',
  },
  {
    id: 'hongik-3',
    name: '홍대 관광안내소 보관함',
    nameEn: 'Hongdae Tourist Info Center Locker',
    zone: 'hongik',
    location: '홍대 관광안내소 1층 (홍대 정문 앞)',
    locationEn: 'Hongdae Tourist Info Center 1F (Main Gate)',
    address: '서울특별시 마포구 어울마당로 35',
    lat: 37.5565,
    lng: 126.9237,
    available: true,
    sizes: { small: true, medium: true, large: true },
    feePerHour: { small: 1000, medium: 2000, large: 2500 },
    travelMinutes: 10,
    returnEase: 'good',
    operatingHours: '09:00 - 21:00',
    notes: '관광안내소 내 위치, 다국어 안내 가능, 홍대 거리 중심부 접근 최적',
    notesEn: 'Located in tourist center, multilingual support, best access to Hongdae center',
  },

  // 명동 권역
  {
    id: 'myeongdong-1',
    name: '명동역 4번 출구 물품보관함',
    nameEn: 'Myeongdong Station Exit 4 Locker',
    zone: 'myeongdong',
    location: '명동역 4번 출구 지하 1층',
    locationEn: 'Myeongdong Station Exit 4, B1F',
    address: '서울특별시 중구 명동길 14',
    lat: 37.5637,
    lng: 126.9850,
    available: true,
    sizes: { small: true, medium: true, large: true },
    feePerHour: { small: 1000, medium: 2000, large: 3000 },
    travelMinutes: 3,
    returnEase: 'good',
    operatingHours: '06:00 - 23:00',
    notes: '명동 쇼핑 후 복귀 최적, 대형 캐리어 보관 가능, 엘리베이터 접근 가능',
    notesEn: 'Best return after Myeongdong shopping, large luggage available, elevator access',
  },
  {
    id: 'myeongdong-2',
    name: '명동 관광안내소 보관함',
    nameEn: 'Myeongdong Tourist Info Locker',
    zone: 'myeongdong',
    location: '명동 관광안내소 (명동길 중앙)',
    locationEn: 'Myeongdong Tourist Info Center (Central)',
    address: '서울특별시 중구 명동길 74',
    lat: 37.5641,
    lng: 126.9856,
    available: true,
    sizes: { small: true, medium: true, large: false },
    feePerHour: { small: 1000, medium: 2000, large: 0 },
    travelMinutes: 6,
    returnEase: 'good',
    operatingHours: '09:00 - 21:00',
    notes: '명동 중심부 위치, 쇼핑 중 짐 맡기기 최적, 외국어 안내 가능',
    notesEn: 'Central Myeongdong location, ideal for shopping, multilingual support',
  },
  {
    id: 'myeongdong-3',
    name: '을지로입구역 공영보관함',
    nameEn: 'Euljiro 1-ga Station Public Locker',
    zone: 'myeongdong',
    location: '을지로입구역 2번 출구 인근',
    locationEn: 'Near Euljiro 1-ga Station Exit 2',
    address: '서울특별시 중구 을지로 29',
    lat: 37.5660,
    lng: 126.9822,
    available: true,
    sizes: { small: true, medium: true, large: true },
    feePerHour: { small: 800, medium: 1500, large: 2500 },
    travelMinutes: 9,
    returnEase: 'ok',
    operatingHours: '06:00 - 22:00',
    notes: '저렴한 공영 보관함, 명동에서 도보 10분, 지하철 연결 편리',
    notesEn: 'Affordable public locker, 10 min walk from Myeongdong, convenient subway access',
  },
];

// ===== 관광지 데이터 =====
export const touristSpots: TouristSpot[] = [
  // 서울역 권역
  {
    id: 'seoul-spot-1',
    name: '서울로 7017',
    nameEn: 'Seoullo 7017',
    zone: 'seoul',
    category: '도시공원',
    categoryEn: 'Urban Park',
    indoor: false,
    durationMin: 40,
    distanceFromLocker: 5,
    tags: ['산책', '사진', '야외'],
    tagsEn: ['Walk', 'Photo', 'Outdoor'],
    description: '옛 고가도로를 공원으로 변신시킨 서울의 명소. 도심 속 산책과 사진 촬영에 최적.',
    descriptionEn: 'A former elevated highway transformed into a scenic urban park. Perfect for walks and photos.',
    imageEmoji: '🌿',
  },
  {
    id: 'seoul-spot-2',
    name: '서울역사박물관',
    nameEn: 'Seoul Museum of History',
    zone: 'seoul',
    category: '박물관',
    categoryEn: 'Museum',
    indoor: true,
    durationMin: 60,
    distanceFromLocker: 15,
    tags: ['실내', '역사', '문화'],
    tagsEn: ['Indoor', 'History', 'Culture'],
    description: '서울의 역사와 문화를 한눈에 볼 수 있는 무료 박물관.',
    descriptionEn: 'Free museum showcasing Seoul\'s history and culture.',
    imageEmoji: '🏛️',
  },
  {
    id: 'seoul-spot-3',
    name: '남대문시장',
    nameEn: 'Namdaemun Market',
    zone: 'seoul',
    category: '전통시장',
    categoryEn: 'Traditional Market',
    indoor: false,
    durationMin: 50,
    distanceFromLocker: 10,
    tags: ['쇼핑', '먹거리', '전통'],
    tagsEn: ['Shopping', 'Food', 'Traditional'],
    description: '한국 최대 전통시장. 다양한 먹거리와 쇼핑을 즐길 수 있는 곳.',
    descriptionEn: 'Korea\'s largest traditional market with diverse food and shopping.',
    imageEmoji: '🛍️',
  },
  {
    id: 'seoul-spot-4',
    name: '숭례문 (남대문)',
    nameEn: 'Sungnyemun (Namdaemun Gate)',
    zone: 'seoul',
    category: '문화재',
    categoryEn: 'Cultural Heritage',
    indoor: false,
    durationMin: 20,
    distanceFromLocker: 8,
    tags: ['사진', '역사', '야외'],
    tagsEn: ['Photo', 'History', 'Outdoor'],
    description: '조선시대 한양 도성의 남쪽 성문. 서울의 대표적인 문화재.',
    descriptionEn: 'The southern gate of Hanyang fortress from the Joseon Dynasty.',
    imageEmoji: '🏯',
  },

  // 홍대입구역 권역
  {
    id: 'hongik-spot-1',
    name: '홍대 거리 (걷고싶은거리)',
    nameEn: 'Hongdae Street (Walking Street)',
    zone: 'hongik',
    category: '거리/문화',
    categoryEn: 'Street/Culture',
    indoor: false,
    durationMin: 60,
    distanceFromLocker: 5,
    tags: ['산책', '쇼핑', '사진', '문화'],
    tagsEn: ['Walk', 'Shopping', 'Photo', 'Culture'],
    description: '젊음과 예술의 거리. 개성 넘치는 카페, 편집숍, 버스킹을 즐길 수 있는 곳.',
    descriptionEn: 'A vibrant street of youth and art with unique cafes, shops, and busking.',
    imageEmoji: '🎨',
  },
  {
    id: 'hongik-spot-2',
    name: '경의선 숲길',
    nameEn: 'Gyeongui Line Forest Road',
    zone: 'hongik',
    category: '도시공원',
    categoryEn: 'Urban Park',
    indoor: false,
    durationMin: 45,
    distanceFromLocker: 8,
    tags: ['산책', '자연', '사진'],
    tagsEn: ['Walk', 'Nature', 'Photo'],
    description: '옛 경의선 철길을 따라 조성된 선형 공원. 계절마다 아름다운 풍경.',
    descriptionEn: 'A linear park along the former Gyeongui railway line with seasonal scenery.',
    imageEmoji: '🌸',
  },
  {
    id: 'hongik-spot-3',
    name: '홍대 카페거리',
    nameEn: 'Hongdae Cafe Street',
    zone: 'hongik',
    category: '카페/식사',
    categoryEn: 'Cafe/Dining',
    indoor: true,
    durationMin: 60,
    distanceFromLocker: 6,
    tags: ['실내', '카페', '식사', '사진'],
    tagsEn: ['Indoor', 'Cafe', 'Dining', 'Photo'],
    description: '개성 넘치는 카페들이 밀집한 거리. 브런치와 디저트를 즐기기 좋은 곳.',
    descriptionEn: 'A street packed with unique cafes, perfect for brunch and desserts.',
    imageEmoji: '☕',
  },
  {
    id: 'hongik-spot-4',
    name: '연남동 골목',
    nameEn: 'Yeonnam-dong Alley',
    zone: 'hongik',
    category: '거리/문화',
    categoryEn: 'Street/Culture',
    indoor: false,
    durationMin: 40,
    distanceFromLocker: 12,
    tags: ['산책', '사진', '맛집'],
    tagsEn: ['Walk', 'Photo', 'Food'],
    description: '감성적인 카페와 레스토랑이 가득한 연남동 골목. 조용한 산책에 최적.',
    descriptionEn: 'Charming alleys in Yeonnam-dong filled with cozy cafes and restaurants.',
    imageEmoji: '🏘️',
  },

  // 명동 권역
  {
    id: 'myeongdong-spot-1',
    name: '명동 쇼핑거리',
    nameEn: 'Myeongdong Shopping Street',
    zone: 'myeongdong',
    category: '쇼핑',
    categoryEn: 'Shopping',
    indoor: false,
    durationMin: 60,
    distanceFromLocker: 3,
    tags: ['쇼핑', '먹거리', '화장품'],
    tagsEn: ['Shopping', 'Food', 'Cosmetics'],
    description: '한국 최대 쇼핑 거리. 화장품, 패션, 길거리 음식을 즐길 수 있는 곳.',
    descriptionEn: 'Korea\'s top shopping street for cosmetics, fashion, and street food.',
    imageEmoji: '🛒',
  },
  {
    id: 'myeongdong-spot-2',
    name: '명동성당',
    nameEn: 'Myeongdong Cathedral',
    zone: 'myeongdong',
    category: '문화재',
    categoryEn: 'Cultural Heritage',
    indoor: true,
    durationMin: 30,
    distanceFromLocker: 7,
    tags: ['사진', '역사', '실내'],
    tagsEn: ['Photo', 'History', 'Indoor'],
    description: '서울의 대표적인 고딕 양식 성당. 아름다운 건축과 조용한 분위기.',
    descriptionEn: 'Seoul\'s iconic Gothic cathedral with beautiful architecture and peaceful atmosphere.',
    imageEmoji: '⛪',
  },
  {
    id: 'myeongdong-spot-3',
    name: '남산 N서울타워',
    nameEn: 'N Seoul Tower (Namsan)',
    zone: 'myeongdong',
    category: '전망대',
    categoryEn: 'Observatory',
    indoor: true,
    durationMin: 90,
    distanceFromLocker: 20,
    tags: ['사진', '전망', '실내'],
    tagsEn: ['Photo', 'View', 'Indoor'],
    description: '서울 전경을 한눈에 볼 수 있는 남산 N서울타워. 케이블카 이용 가능.',
    descriptionEn: 'Panoramic views of Seoul from N Seoul Tower on Namsan. Cable car available.',
    imageEmoji: '🗼',
  },
  {
    id: 'myeongdong-spot-4',
    name: '명동 먹자골목',
    nameEn: 'Myeongdong Food Alley',
    zone: 'myeongdong',
    category: '식사',
    categoryEn: 'Dining',
    indoor: false,
    durationMin: 45,
    distanceFromLocker: 4,
    tags: ['식사', '먹거리', '길거리음식'],
    tagsEn: ['Dining', 'Food', 'Street Food'],
    description: '다양한 한국 음식과 길거리 음식을 즐길 수 있는 명동의 먹자골목.',
    descriptionEn: 'Enjoy diverse Korean food and street food in Myeongdong\'s food alley.',
    imageEmoji: '🍜',
  },
];

// ===== 코스 데이터 =====
export const courses: Course[] = [
  // 서울역 권역 코스
  {
    id: 'seoul-course-1',
    name: '서울로 7017 산책 코스',
    nameEn: 'Seoullo 7017 Walking Course',
    zone: 'seoul',
    totalMinutes: 90,
    indoor: false,
    difficulty: 'easy',
    spots: ['seoul-spot-1', 'seoul-spot-4'],
    description: '서울로 7017을 따라 걸으며 숭례문까지 이어지는 가벼운 산책 코스. 사진 찍기 좋은 포인트 다수.',
    descriptionEn: 'A light walking course along Seoullo 7017 to Sungnyemun Gate. Many great photo spots.',
    returnConvenience: '서울역에서 도보 5분 이내 복귀 가능',
    returnConvenienceEn: 'Can return to Seoul Station within 5 min on foot',
    includesMeal: false,
    tags: ['산책', '사진', '야외'],
  },
  {
    id: 'seoul-course-2',
    name: '남대문시장 + 숭례문 코스',
    nameEn: 'Namdaemun Market + Sungnyemun Course',
    zone: 'seoul',
    totalMinutes: 120,
    indoor: false,
    difficulty: 'easy',
    spots: ['seoul-spot-3', 'seoul-spot-4'],
    description: '남대문시장에서 쇼핑과 먹거리를 즐기고 숭례문을 둘러보는 코스. 식사 포함 가능.',
    descriptionEn: 'Enjoy shopping and food at Namdaemun Market, then visit Sungnyemun Gate.',
    returnConvenience: '서울역에서 도보 10분, 지하철 1정거장',
    returnConvenienceEn: '10 min walk or 1 subway stop from Seoul Station',
    includesMeal: true,
    tags: ['쇼핑', '식사', '역사'],
  },
  {
    id: 'seoul-course-3',
    name: '서울역사박물관 실내 코스',
    nameEn: 'Seoul Museum of History Indoor Course',
    zone: 'seoul',
    totalMinutes: 90,
    indoor: true,
    difficulty: 'easy',
    spots: ['seoul-spot-2'],
    description: '무료 입장 가능한 서울역사박물관에서 서울의 역사와 문화를 즐기는 실내 코스.',
    descriptionEn: 'Explore Seoul\'s history and culture at the free Seoul Museum of History.',
    returnConvenience: '지하철 5호선 광화문역 이용, 서울역까지 15분',
    returnConvenienceEn: 'Take Line 5 from Gwanghwamun, 15 min to Seoul Station',
    includesMeal: false,
    tags: ['실내', '역사', '무료'],
  },

  // 홍대 권역 코스
  {
    id: 'hongik-course-1',
    name: '홍대 거리 + 경의선 숲길 코스',
    nameEn: 'Hongdae Street + Forest Road Course',
    zone: 'hongik',
    totalMinutes: 120,
    indoor: false,
    difficulty: 'easy',
    spots: ['hongik-spot-1', 'hongik-spot-2'],
    description: '홍대 걷고싶은거리를 구경하고 경의선 숲길을 따라 산책하는 가벼운 코스.',
    descriptionEn: 'Stroll through Hongdae Walking Street and along the Gyeongui Line Forest Road.',
    returnConvenience: '홍대입구역 도보 5분 이내',
    returnConvenienceEn: 'Within 5 min walk to Hongik Univ. Station',
    includesMeal: false,
    tags: ['산책', '사진', '문화'],
  },
  {
    id: 'hongik-course-2',
    name: '홍대 카페 + 연남동 코스',
    nameEn: 'Hongdae Cafe + Yeonnam-dong Course',
    zone: 'hongik',
    totalMinutes: 150,
    indoor: true,
    difficulty: 'easy',
    spots: ['hongik-spot-3', 'hongik-spot-4'],
    description: '홍대 카페거리에서 브런치를 즐기고 연남동 골목을 산책하는 감성 코스.',
    descriptionEn: 'Enjoy brunch at Hongdae Cafe Street and explore charming Yeonnam-dong alleys.',
    returnConvenience: '홍대입구역 도보 10분',
    returnConvenienceEn: '10 min walk to Hongik Univ. Station',
    includesMeal: true,
    tags: ['카페', '식사', '산책'],
  },
  {
    id: 'hongik-course-3',
    name: '홍대 쇼핑 + 버스킹 코스',
    nameEn: 'Hongdae Shopping + Busking Course',
    zone: 'hongik',
    totalMinutes: 90,
    indoor: false,
    difficulty: 'easy',
    spots: ['hongik-spot-1'],
    description: '홍대 편집숍과 인디 브랜드 쇼핑, 거리 버스킹을 즐기는 활기찬 코스.',
    descriptionEn: 'Enjoy indie brand shopping and street busking in the vibrant Hongdae area.',
    returnConvenience: '홍대입구역 도보 5분',
    returnConvenienceEn: '5 min walk to Hongik Univ. Station',
    includesMeal: false,
    tags: ['쇼핑', '문화', '야외'],
  },

  // 명동 권역 코스
  {
    id: 'myeongdong-course-1',
    name: '명동 쇼핑 + 먹거리 코스',
    nameEn: 'Myeongdong Shopping + Food Course',
    zone: 'myeongdong',
    totalMinutes: 120,
    indoor: false,
    difficulty: 'easy',
    spots: ['myeongdong-spot-1', 'myeongdong-spot-4'],
    description: '명동 쇼핑거리에서 화장품·패션 쇼핑 후 먹자골목에서 한국 음식을 즐기는 코스.',
    descriptionEn: 'Shop for cosmetics and fashion in Myeongdong, then enjoy Korean food in the food alley.',
    returnConvenience: '명동역 도보 3분',
    returnConvenienceEn: '3 min walk to Myeongdong Station',
    includesMeal: true,
    tags: ['쇼핑', '식사', '화장품'],
  },
  {
    id: 'myeongdong-course-2',
    name: '명동성당 + 쇼핑 코스',
    nameEn: 'Myeongdong Cathedral + Shopping Course',
    zone: 'myeongdong',
    totalMinutes: 90,
    indoor: true,
    difficulty: 'easy',
    spots: ['myeongdong-spot-2', 'myeongdong-spot-1'],
    description: '명동성당의 아름다운 건축을 감상하고 명동 쇼핑거리를 둘러보는 코스.',
    descriptionEn: 'Admire Myeongdong Cathedral\'s architecture, then explore the shopping street.',
    returnConvenience: '명동역 도보 5분',
    returnConvenienceEn: '5 min walk to Myeongdong Station',
    includesMeal: false,
    tags: ['사진', '역사', '쇼핑'],
  },
  {
    id: 'myeongdong-course-3',
    name: 'N서울타워 전망 코스',
    nameEn: 'N Seoul Tower View Course',
    zone: 'myeongdong',
    totalMinutes: 150,
    indoor: true,
    difficulty: 'medium',
    spots: ['myeongdong-spot-3'],
    description: '남산 케이블카를 타고 N서울타워에서 서울 전경을 감상하는 프리미엄 코스.',
    descriptionEn: 'Take the cable car to N Seoul Tower for panoramic views of Seoul.',
    returnConvenience: '명동역 또는 충무로역 도보 20분',
    returnConvenienceEn: '20 min walk to Myeongdong or Chungmuro Station',
    includesMeal: false,
    tags: ['전망', '사진', '실내'],
  },
];

// ===== 이동 경로 데이터 =====
export const routes: RouteOption[] = [
  // 서울역 → 서울로 7017
  {
    id: 'route-seoul-1-shortest',
    type: 'shortest',
    from: '서울역',
    to: '서울로 7017',
    durationMinutes: 5,
    difficulty: 'medium',
    transfers: 0,
    stairsAvoided: false,
    elevatorAvailable: true,
    escalatorAvailable: true,
    steps: [
      { type: 'walk', description: '서울역 1번 출구로 나오기', descriptionEn: 'Exit Seoul Station via Exit 1', durationMinutes: 2, icon: '🚶' },
      { type: 'walk', description: '서울로 7017 입구까지 도보', descriptionEn: 'Walk to Seoullo 7017 entrance', durationMinutes: 3, icon: '🚶' },
    ],
  },
  {
    id: 'route-seoul-1-easiest',
    type: 'easiest',
    from: '서울역',
    to: '서울로 7017',
    durationMinutes: 7,
    difficulty: 'easy',
    transfers: 0,
    stairsAvoided: true,
    elevatorAvailable: true,
    escalatorAvailable: true,
    steps: [
      { type: 'elevator', description: '서울역 엘리베이터 이용 (1층 → 지상)', descriptionEn: 'Use elevator at Seoul Station (B1 → Ground)', durationMinutes: 2, icon: '🛗' },
      { type: 'walk', description: '서울로 7017 엘리베이터 입구까지 도보', descriptionEn: 'Walk to Seoullo 7017 elevator entrance', durationMinutes: 5, icon: '🚶' },
    ],
  },
  // 홍대입구역 → 홍대 거리
  {
    id: 'route-hongik-1-shortest',
    type: 'shortest',
    from: '홍대입구역',
    to: '홍대 거리',
    durationMinutes: 5,
    difficulty: 'easy',
    transfers: 0,
    stairsAvoided: false,
    elevatorAvailable: true,
    escalatorAvailable: true,
    steps: [
      { type: 'walk', description: '홍대입구역 9번 출구로 나오기', descriptionEn: 'Exit Hongik Univ. Station via Exit 9', durationMinutes: 2, icon: '🚶' },
      { type: 'walk', description: '홍대 걷고싶은거리까지 도보', descriptionEn: 'Walk to Hongdae Walking Street', durationMinutes: 3, icon: '🚶' },
    ],
  },
  {
    id: 'route-hongik-1-easiest',
    type: 'easiest',
    from: '홍대입구역',
    to: '홍대 거리',
    durationMinutes: 8,
    difficulty: 'easy',
    transfers: 0,
    stairsAvoided: true,
    elevatorAvailable: true,
    escalatorAvailable: true,
    steps: [
      { type: 'escalator', description: '홍대입구역 에스컬레이터 이용', descriptionEn: 'Use escalator at Hongik Univ. Station', durationMinutes: 2, icon: '🔼' },
      { type: 'walk', description: '2번 출구 방향 평지 경로로 홍대 거리까지', descriptionEn: 'Take flat route via Exit 2 to Hongdae Street', durationMinutes: 6, icon: '🚶' },
    ],
  },
  // 명동역 → 명동 쇼핑거리
  {
    id: 'route-myeongdong-1-shortest',
    type: 'shortest',
    from: '명동역',
    to: '명동 쇼핑거리',
    durationMinutes: 3,
    difficulty: 'easy',
    transfers: 0,
    stairsAvoided: false,
    elevatorAvailable: true,
    escalatorAvailable: true,
    steps: [
      { type: 'walk', description: '명동역 5번 출구로 나오기', descriptionEn: 'Exit Myeongdong Station via Exit 5', durationMinutes: 1, icon: '🚶' },
      { type: 'walk', description: '명동 쇼핑거리 진입', descriptionEn: 'Enter Myeongdong Shopping Street', durationMinutes: 2, icon: '🚶' },
    ],
  },
  {
    id: 'route-myeongdong-1-easiest',
    type: 'easiest',
    from: '명동역',
    to: '명동 쇼핑거리',
    durationMinutes: 5,
    difficulty: 'easy',
    transfers: 0,
    stairsAvoided: true,
    elevatorAvailable: true,
    escalatorAvailable: true,
    steps: [
      { type: 'elevator', description: '명동역 엘리베이터 이용 (지하 → 지상)', descriptionEn: 'Use elevator at Myeongdong Station (B → Ground)', durationMinutes: 2, icon: '🛗' },
      { type: 'walk', description: '평지 경로로 명동 쇼핑거리까지', descriptionEn: 'Take flat route to Myeongdong Shopping Street', durationMinutes: 3, icon: '🚶' },
    ],
  },
];

// ===== 짐 크기 분류 로직 =====
export function getLuggageSize(luggageTypes: string[]): LockerSize {
  if (luggageTypes.includes('28인치 캐리어') || luggageTypes.includes('24인치 캐리어')) {
    return 'large';
  }
  if (luggageTypes.includes('기내용 캐리어') || luggageTypes.includes('쇼핑백') || luggageTypes.includes('선물상자')) {
    return 'medium';
  }
  return 'small';
}

// 영어 짐 크기 분류
export function getLuggageSizeEn(luggageTypes: string[]): LockerSize {
  if (luggageTypes.includes('28" Suitcase') || luggageTypes.includes('24" Suitcase')) {
    return 'large';
  }
  if (luggageTypes.includes('Carry-on') || luggageTypes.includes('Shopping Bag') || luggageTypes.includes('Gift Box')) {
    return 'medium';
  }
  return 'small';
}

// 권역 코드 매핑
export const zoneMap: Record<string, string> = {
  '서울역': 'seoul',
  '홍대입구역': 'hongik',
  '명동역': 'myeongdong',
  'Seoul Station': 'seoul',
  'Hongik Univ. Station': 'hongik',
  'Myeongdong Station': 'myeongdong',
};
