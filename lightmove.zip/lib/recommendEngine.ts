// 라이트무브 AI 추천 엔진
// 규칙 기반(Rule-Based) 추천 로직
// ※ 실제 AI/ML 모델 연동 전 데모용 규칙 기반 엔진입니다.

import {
  lockers,
  courses,
  routes,
  getLuggageSize,
  getLuggageSizeEn,
  zoneMap,
  type Locker,
  type Course,
  type RouteOption,
  type LockerSize,
} from './sampleData';

export interface UserInput {
  situation: 'before-checkin' | 'after-checkout';
  location: string;
  nextScheduleTime: Date;
  luggageTypes: string[];
  movePrefers: string[];
  tourPrefers: string[];
  language: 'ko' | 'en';
}

export interface FreeTimeCalc {
  moveToLockerMin: number;
  storeProcessMin: number;
  freeTimeMin: number;
  returnToLockerMin: number;
  bufferMin: number;
  totalFreeTimeMin: number;
  suggestedReturnTime: Date;
  nextScheduleTime: Date;
}

export interface RecommendResult {
  aiSummary: string;
  freeTimeCalc: FreeTimeCalc;
  recommendedLockers: Locker[];
  recommendedCourses: Course[];
  recommendedRoutes: RouteOption[];
  luggageSize: LockerSize;
  zone: string;
}

// 자유시간 계산
export function calcFreeTime(
  input: UserInput,
  selectedLocker: Locker,
): FreeTimeCalc {
  const now = new Date();
  const totalMinutesLeft = Math.floor(
    (input.nextScheduleTime.getTime() - now.getTime()) / 60000,
  );

  const moveToLockerMin = selectedLocker.travelMinutes;
  const storeProcessMin = 5; // 보관 처리 시간
  const returnToLockerMin = selectedLocker.travelMinutes + 5; // 복귀 + 짐 찾기
  const bufferMin = 15; // 여유 시간

  const freeTimeMin = Math.max(
    0,
    totalMinutesLeft - moveToLockerMin - storeProcessMin - returnToLockerMin - bufferMin,
  );

  const suggestedReturnTime = new Date(
    input.nextScheduleTime.getTime() - (returnToLockerMin + bufferMin) * 60000,
  );

  return {
    moveToLockerMin,
    storeProcessMin,
    freeTimeMin,
    returnToLockerMin,
    bufferMin,
    totalFreeTimeMin: freeTimeMin,
    suggestedReturnTime,
    nextScheduleTime: input.nextScheduleTime,
  };
}

// 보관함 추천
function recommendLockers(input: UserInput, luggageSize: LockerSize): Locker[] {
  const zone = zoneMap[input.location] || 'seoul';

  const zoneLockers = lockers.filter((l) => l.zone === zone);

  // 짐 크기 필터링
  const sizeFiltered = zoneLockers.filter((l) => {
    if (luggageSize === 'large') return l.sizes.large;
    if (luggageSize === 'medium') return l.sizes.medium;
    return l.sizes.small;
  });

  // 이동 선호 반영 (엘리베이터 우선 등은 경로 추천에서 반영)
  // 이용 가능 여부 우선 정렬
  const sorted = [...sizeFiltered].sort((a, b) => {
    if (a.available && !b.available) return -1;
    if (!a.available && b.available) return 1;
    // 복귀 편의성 정렬
    const easeScore = { good: 3, ok: 2, poor: 1 };
    const easeDiff = easeScore[b.returnEase] - easeScore[a.returnEase];
    if (easeDiff !== 0) return easeDiff;
    // 이동 시간 정렬
    return a.travelMinutes - b.travelMinutes;
  });

  return sorted.slice(0, 3);
}

// 코스 추천
function recommendCourses(input: UserInput, freeTimeMin: number): Course[] {
  const zone = zoneMap[input.location] || 'seoul';
  const zoneCourses = courses.filter((c) => c.zone === zone);

  // 자유시간 내 코스 필터
  const timeFiltered = zoneCourses.filter((c) => c.totalMinutes <= freeTimeMin + 20);

  // 관광 선호 반영
  const preferIndoor =
    input.tourPrefers.includes('실내 위주') || input.tourPrefers.includes('Mostly Indoor');
  const preferMeal =
    input.tourPrefers.includes('식사 포함') || input.tourPrefers.includes('Include Meal');
  const preferPhoto =
    input.tourPrefers.includes('사진 찍기 좋은 곳') || input.tourPrefers.includes('Photo Spots');
  const preferShopping =
    input.tourPrefers.includes('쇼핑 포함') || input.tourPrefers.includes('Shopping');

  const scored = timeFiltered.map((c) => {
    let score = 0;
    if (preferIndoor && c.indoor) score += 3;
    if (!preferIndoor && !c.indoor) score += 2;
    if (preferMeal && c.includesMeal) score += 3;
    if (preferPhoto && (c.tags.includes('사진') || c.tags.includes('Photo'))) score += 2;
    if (preferShopping && (c.tags.includes('쇼핑') || c.tags.includes('Shopping'))) score += 2;
    // 시간 적합도 점수
    const timeDiff = Math.abs(c.totalMinutes - freeTimeMin);
    score += Math.max(0, 10 - timeDiff / 10);
    return { course: c, score };
  });

  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, 3).map((s) => s.course);
}

// 이동 경로 추천
function recommendRoutes(input: UserInput, targetSpot: string): RouteOption[] {
  const zone = zoneMap[input.location] || 'seoul';
  const preferElevator =
    input.movePrefers.includes('엘리베이터 우선') || input.movePrefers.includes('Elevator First');
  const preferEscalator =
    input.movePrefers.includes('에스컬레이터 우선') || input.movePrefers.includes('Escalator First');
  const preferNoStairs =
    input.movePrefers.includes('계단 적은 경로') || input.movePrefers.includes('Fewer Stairs');

  // 해당 권역 경로 필터
  const zoneRoutes = routes.filter((r) => {
    if (zone === 'seoul') return r.from.includes('서울역') || r.from.includes('Seoul');
    if (zone === 'hongik') return r.from.includes('홍대') || r.from.includes('Hongik');
    if (zone === 'myeongdong') return r.from.includes('명동') || r.from.includes('Myeongdong');
    return false;
  });

  // 이동 선호에 따른 정렬
  if (preferElevator || preferNoStairs || preferEscalator) {
    // 편한 경로 우선
    return zoneRoutes.sort((a, b) => {
      if (a.type === 'easiest' && b.type !== 'easiest') return -1;
      if (a.type !== 'easiest' && b.type === 'easiest') return 1;
      return 0;
    });
  }

  return zoneRoutes;
}

// AI 요약 문장 생성
function generateAISummary(
  input: UserInput,
  luggageSize: LockerSize,
  freeTimeMin: number,
  recommendedLockers: Locker[],
  recommendedCourses: Course[],
): string {
  const isKo = input.language === 'ko';
  const topLocker = recommendedLockers[0];
  const topCourse = recommendedCourses[0];

  const lines: string[] = [];

  // 짐 크기 관련
  if (luggageSize === 'large') {
    lines.push(
      isKo
        ? '짐이 큰 편이어서 대형 보관 가능 보관함을 우선 추천합니다.'
        : 'Your luggage is large, so we prioritize lockers with large storage.',
    );
  } else if (luggageSize === 'medium') {
    lines.push(
      isKo
        ? '중형 짐에 맞는 보관함을 추천합니다.'
        : 'We recommend lockers suitable for medium-sized luggage.',
    );
  } else {
    lines.push(
      isKo
        ? '소형 짐이라 선택 가능한 보관함이 많습니다.'
        : 'Your small luggage gives you many locker options.',
    );
  }

  // 자유시간 관련
  if (freeTimeMin < 60) {
    lines.push(
      isKo
        ? `남은 시간이 짧아 현재 역 근처 보관함이 가장 적합합니다.`
        : 'With limited time, the nearest locker is your best option.',
    );
  } else if (freeTimeMin >= 120) {
    lines.push(
      isKo
        ? `자유시간이 충분해 다양한 코스를 즐길 수 있습니다.`
        : 'You have plenty of free time to enjoy various courses.',
    );
  } else {
    lines.push(
      isKo
        ? `지금 맡기면 자유시간 약 ${freeTimeMin}분을 확보할 수 있습니다.`
        : `Storing now gives you about ${freeTimeMin} minutes of free time.`,
    );
  }

  // 보관함 추천
  if (topLocker) {
    lines.push(
      isKo
        ? `${topLocker.name}이(가) 현재 위치에서 ${topLocker.travelMinutes}분 거리로 가장 적합합니다.`
        : `${topLocker.nameEn} is the best option, ${topLocker.travelMinutes} min from your location.`,
    );
  }

  // 관광 선호 반영
  const preferIndoor =
    input.tourPrefers.includes('실내 위주') || input.tourPrefers.includes('Mostly Indoor');
  if (preferIndoor) {
    lines.push(
      isKo
        ? '실내 코스를 선호하셔서 실내 위주 코스를 우선 추천합니다.'
        : 'You prefer indoor activities, so we prioritize indoor courses.',
    );
  }

  // 코스 추천
  if (topCourse) {
    const courseName = isKo ? topCourse.name : topCourse.nameEn;
    lines.push(
      isKo
        ? `'${courseName}'이(가) 남은 시간과 선호에 가장 잘 맞는 코스입니다.`
        : `'${courseName}' is the best match for your time and preferences.`,
    );
  }

  return lines.join('\n');
}

// 메인 추천 함수
export function getRecommendations(input: UserInput): RecommendResult {
  const luggageSize =
    input.language === 'ko'
      ? getLuggageSize(input.luggageTypes)
      : getLuggageSizeEn(input.luggageTypes);

  const zone = zoneMap[input.location] || 'seoul';

  const recommendedLockers = recommendLockers(input, luggageSize);
  const topLocker = recommendedLockers[0];

  const freeTimeCalc = topLocker
    ? calcFreeTime(input, topLocker)
    : {
        moveToLockerMin: 5,
        storeProcessMin: 5,
        freeTimeMin: 120,
        returnToLockerMin: 10,
        bufferMin: 15,
        totalFreeTimeMin: 120,
        suggestedReturnTime: new Date(input.nextScheduleTime.getTime() - 25 * 60000),
        nextScheduleTime: input.nextScheduleTime,
      };

  const recommendedCourses = recommendCourses(input, freeTimeCalc.freeTimeMin);
  const recommendedRoutes = recommendRoutes(input, '');

  const aiSummary = generateAISummary(
    input,
    luggageSize,
    freeTimeCalc.freeTimeMin,
    recommendedLockers,
    recommendedCourses,
  );

  return {
    aiSummary,
    freeTimeCalc,
    recommendedLockers,
    recommendedCourses,
    recommendedRoutes,
    luggageSize,
    zone,
  };
}

// 시간 포맷 유틸
export function formatTime(date: Date, format24h: boolean): string {
  const h = date.getHours();
  const m = date.getMinutes().toString().padStart(2, '0');
  if (format24h) {
    return `${h.toString().padStart(2, '0')}:${m}`;
  }
  const period = h >= 12 ? 'PM' : 'AM';
  const h12 = h % 12 || 12;
  return `${h12}:${m} ${period}`;
}

export function formatDuration(minutes: number, lang: 'ko' | 'en'): string {
  if (minutes < 60) {
    return lang === 'ko' ? `${minutes}분` : `${minutes}min`;
  }
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (m === 0) {
    return lang === 'ko' ? `${h}시간` : `${h}hr`;
  }
  return lang === 'ko' ? `${h}시간 ${m}분` : `${h}hr ${m}min`;
}
