import React, { createContext, useContext, useState, useCallback } from 'react';
import type { Language, Translations } from './i18n';
import { translations } from './i18n';
import type { UserInput, RecommendResult } from './recommendEngine';
import type { Locker, Course } from './sampleData';

interface AppState {
  language: Language;
  timeFormat24h: boolean;
  onboardingDone: boolean;
  userInput: UserInput | null;
  recommendResult: RecommendResult | null;
  selectedLocker: Locker | null;
  selectedCourse: Course | null;
}

interface AppContextValue extends AppState {
  t: Translations;
  setLanguage: (lang: Language) => void;
  setTimeFormat24h: (v: boolean) => void;
  setOnboardingDone: () => void;
  setUserInput: (input: UserInput) => void;
  setRecommendResult: (result: RecommendResult) => void;
  setSelectedLocker: (locker: Locker | null) => void;
  setSelectedCourse: (course: Course | null) => void;
  reset: () => void;
}

const defaultState: AppState = {
  language: 'ko',
  timeFormat24h: true,
  onboardingDone: false,
  userInput: null,
  recommendResult: null,
  selectedLocker: null,
  selectedCourse: null,
};

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AppState>(defaultState);

  const setLanguage = useCallback((lang: Language) => {
    setState((s) => ({ ...s, language: lang }));
  }, []);

  const setTimeFormat24h = useCallback((v: boolean) => {
    setState((s) => ({ ...s, timeFormat24h: v }));
  }, []);

  const setOnboardingDone = useCallback(() => {
    setState((s) => ({ ...s, onboardingDone: true }));
  }, []);

  const setUserInput = useCallback((input: UserInput) => {
    setState((s) => ({ ...s, userInput: input }));
  }, []);

  const setRecommendResult = useCallback((result: RecommendResult) => {
    setState((s) => ({ ...s, recommendResult: result }));
  }, []);

  const setSelectedLocker = useCallback((locker: Locker | null) => {
    setState((s) => ({ ...s, selectedLocker: locker }));
  }, []);

  const setSelectedCourse = useCallback((course: Course | null) => {
    setState((s) => ({ ...s, selectedCourse: course }));
  }, []);

  const reset = useCallback(() => {
    setState((s) => ({
      ...defaultState,
      language: s.language,
      timeFormat24h: s.timeFormat24h,
      onboardingDone: s.onboardingDone,
    }));
  }, []);

  const t = translations[state.language] as unknown as Translations;

  return (
    <AppContext.Provider
      value={{
        ...state,
        t,
        setLanguage,
        setTimeFormat24h,
        setOnboardingDone,
        setUserInput,
        setRecommendResult,
        setSelectedLocker,
        setSelectedCourse,
        reset,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
