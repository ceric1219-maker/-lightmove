import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
} from 'react-native';
import { router } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useApp } from '@/lib/AppContext';
import { useColors } from '@/hooks/use-colors';
import { routes } from '@/lib/sampleData';
import { zoneMap } from '@/lib/sampleData';

export default function LockerDetailScreen() {
  const { t, language, selectedLocker, userInput } = useApp();
  const colors = useColors();
  const [showReserveNote, setShowReserveNote] = useState(false);

  if (!selectedLocker) {
    return (
      <ScreenContainer>
        <View style={styles.empty}>
          <Text style={[styles.emptyText, { color: colors.muted }]}>{t.common.error}</Text>
          <TouchableOpacity onPress={() => router.back()}>
            <Text style={[styles.retryText, { color: colors.primary }]}>{t.common.back}</Text>
          </TouchableOpacity>
        </View>
      </ScreenContainer>
    );
  }

  const zone = selectedLocker.zone;
  const zoneRoutes = routes.filter((r) => {
    if (zone === 'seoul') return r.from.includes('서울역') || r.from.includes('Seoul');
    if (zone === 'hongik') return r.from.includes('홍대') || r.from.includes('Hongik');
    if (zone === 'myeongdong') return r.from.includes('명동') || r.from.includes('Myeongdong');
    return false;
  });

  const handleReserve = () => {
    setShowReserveNote(true);
    Alert.alert(
      language === 'ko' ? '예약 연계 안내' : 'Reservation Info',
      language === 'ko'
        ? '현재 예약 연계 데모 버전입니다.\n실제 예약은 외부 서비스와 연동 예정입니다.'
        : 'This is a demo reservation flow.\nActual booking will be linked to external services.',
      [{ text: language === 'ko' ? '확인' : 'OK' }],
    );
  };

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={[styles.backText, { color: colors.primary }]}>← {t.common.back}</Text>
          </TouchableOpacity>
          <Text style={[styles.title, { color: colors.foreground }]}>{t.locker.title}</Text>
        </View>

        {/* Map placeholder */}
        <View style={[styles.mapPlaceholder, { backgroundColor: colors.border + '60' }]}>
          <Text style={styles.mapEmoji}>🗺️</Text>
          <Text style={[styles.mapText, { color: colors.muted }]}>
            {language === 'ko' ? '지도 미니맵 (실제 지도 API 연동 예정)' : 'Mini Map (Real map API integration planned)'}
          </Text>
          <View style={[styles.mapPin, { backgroundColor: colors.primary }]}>
            <Text style={styles.mapPinText}>📍</Text>
          </View>
        </View>

        {/* Locker name & status */}
        <View style={[styles.nameCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.nameRow}>
            <Text style={[styles.lockerName, { color: colors.foreground }]}>
              {language === 'ko' ? selectedLocker.name : selectedLocker.nameEn}
            </Text>
            <View style={[
              styles.statusBadge,
              { backgroundColor: selectedLocker.available ? '#DCFCE7' : '#FEE2E2' },
            ]}>
              <Text style={[
                styles.statusText,
                { color: selectedLocker.available ? '#166534' : '#991B1B' },
              ]}>
                {selectedLocker.available ? t.result.available : t.result.unavailable}
              </Text>
            </View>
          </View>
          <Text style={[styles.address, { color: colors.muted }]}>
            📍 {language === 'ko' ? selectedLocker.location : selectedLocker.locationEn}
          </Text>
          <Text style={[styles.address, { color: colors.muted }]}>
            🕐 {selectedLocker.operatingHours}
          </Text>
        </View>

        {/* Size availability */}
        <InfoCard title={`📦 ${t.locker.size}`} colors={colors}>
          <View style={styles.sizeGrid}>
            {([
              { key: 'small', label: t.result.lockerSize.small, emoji: '🎒' },
              { key: 'medium', label: t.result.lockerSize.medium, emoji: '🧳' },
              { key: 'large', label: t.result.lockerSize.large, emoji: '🛄' },
            ] as const).map((s) => (
              <View
                key={s.key}
                style={[
                  styles.sizeItem,
                  {
                    backgroundColor: selectedLocker.sizes[s.key]
                      ? colors.primary + '15'
                      : colors.border + '30',
                    borderColor: selectedLocker.sizes[s.key] ? colors.primary : colors.border,
                  },
                ]}
              >
                <Text style={styles.sizeEmoji}>{s.emoji}</Text>
                <Text style={[
                  styles.sizeLabel,
                  { color: selectedLocker.sizes[s.key] ? colors.primary : colors.muted },
                ]}>
                  {s.label}
                </Text>
                <Text style={[
                  styles.sizeCheck,
                  { color: selectedLocker.sizes[s.key] ? '#10B981' : colors.error },
                ]}>
                  {selectedLocker.sizes[s.key] ? '✓' : '✗'}
                </Text>
              </View>
            ))}
          </View>
        </InfoCard>

        {/* Fee */}
        <InfoCard title={`💰 ${t.locker.fee}`} colors={colors}>
          <View style={styles.feeGrid}>
            {([
              { key: 'small', label: t.result.lockerSize.small },
              { key: 'medium', label: t.result.lockerSize.medium },
              { key: 'large', label: t.result.lockerSize.large },
            ] as const).map((s) => (
              <View key={s.key} style={[styles.feeItem, { backgroundColor: colors.background }]}>
                <Text style={[styles.feeLabel, { color: colors.muted }]}>{s.label}</Text>
                <Text style={[styles.feeValue, { color: colors.foreground }]}>
                  {selectedLocker.sizes[s.key]
                    ? `${selectedLocker.feePerHour[s.key].toLocaleString()}${t.locker.perHour}`
                    : '-'}
                </Text>
              </View>
            ))}
          </View>
          <Text style={[styles.feeNote, { color: colors.muted }]}>※ {t.locker.feeNote}</Text>
        </InfoCard>

        {/* Travel info */}
        <InfoCard title={`🚶 ${t.locker.travelTime}`} colors={colors}>
          <View style={styles.travelRow}>
            <View style={[styles.travelItem, { backgroundColor: colors.primary + '15' }]}>
              <Text style={[styles.travelNum, { color: colors.primary }]}>
                {selectedLocker.travelMinutes}분
              </Text>
              <Text style={[styles.travelLabel, { color: colors.muted }]}>
                {language === 'ko' ? '이동 시간' : 'Travel Time'}
              </Text>
            </View>
            <View style={[styles.travelItem, {
              backgroundColor: selectedLocker.returnEase === 'good'
                ? '#DCFCE7'
                : selectedLocker.returnEase === 'ok' ? '#FEF9C3' : '#FEE2E2',
            }]}>
              <Text style={[styles.travelNum, {
                color: selectedLocker.returnEase === 'good'
                  ? '#166534'
                  : selectedLocker.returnEase === 'ok' ? '#854D0E' : '#991B1B',
              }]}>
                {selectedLocker.returnEase === 'good'
                  ? (language === 'ko' ? '우수' : 'Good')
                  : selectedLocker.returnEase === 'ok'
                  ? (language === 'ko' ? '양호' : 'OK')
                  : (language === 'ko' ? '불편' : 'Poor')}
              </Text>
              <Text style={[styles.travelLabel, { color: colors.muted }]}>
                {t.locker.returnEase}
              </Text>
            </View>
          </View>
        </InfoCard>

        {/* Reason */}
        <View style={[styles.reasonCard, { backgroundColor: colors.primary + '10', borderColor: colors.primary + '30' }]}>
          <Text style={[styles.reasonTitle, { color: colors.primary }]}>
            💡 {t.locker.reason}
          </Text>
          <Text style={[styles.reasonText, { color: colors.foreground }]}>
            {language === 'ko' ? selectedLocker.notes : selectedLocker.notesEn}
          </Text>
        </View>

        {/* Route preview */}
        {zoneRoutes.length > 0 && (
          <InfoCard title={`🗺️ ${t.route.title}`} colors={colors}>
            {zoneRoutes.slice(0, 2).map((route) => (
              <TouchableOpacity
                key={route.id}
                style={[styles.routeItem, { borderColor: colors.border }]}
                onPress={() => router.push('/route-detail' as any)}
              >
                <View style={styles.routeHeader}>
                  <Text style={[styles.routeType, { color: colors.foreground }]}>
                    {route.type === 'shortest'
                      ? (language === 'ko' ? '⚡ 최단 경로' : '⚡ Shortest Route')
                      : (language === 'ko' ? '🧳 짐 끌기 편한 경로' : '🧳 Luggage-Friendly Route')}
                  </Text>
                  <View style={[
                    styles.diffBadge,
                    {
                      backgroundColor:
                        route.difficulty === 'easy' ? '#DCFCE7'
                        : route.difficulty === 'medium' ? '#FEF9C3'
                        : '#FEE2E2',
                    },
                  ]}>
                    <Text style={[
                      styles.diffText,
                      {
                        color:
                          route.difficulty === 'easy' ? '#166534'
                          : route.difficulty === 'medium' ? '#854D0E'
                          : '#991B1B',
                      },
                    ]}>
                      {route.difficulty === 'easy'
                        ? t.route.easy
                        : route.difficulty === 'medium'
                        ? t.route.medium
                        : t.route.hard}
                    </Text>
                  </View>
                </View>
                <View style={styles.routeInfo}>
                  <Text style={[styles.routeInfoText, { color: colors.muted }]}>
                    ⏱ {route.durationMinutes}{t.route.minutes}
                  </Text>
                  <Text style={[styles.routeInfoText, { color: colors.muted }]}>
                    🔄 {t.route.transfers}: {route.transfers}{language === 'ko' ? '회' : ''}
                  </Text>
                  {route.elevatorAvailable && (
                    <Text style={[styles.routeInfoText, { color: '#10B981' }]}>
                      🛗 {t.route.elevator}
                    </Text>
                  )}
                </View>
              </TouchableOpacity>
            ))}
            <TouchableOpacity
              style={[styles.routeDetailBtn, { borderColor: colors.primary }]}
              onPress={() => router.push('/route-detail' as any)}
            >
              <Text style={[styles.routeDetailBtnText, { color: colors.primary }]}>
                {language === 'ko' ? '경로 상세 보기 →' : 'View Route Details →'}
              </Text>
            </TouchableOpacity>
          </InfoCard>
        )}

        {/* Reserve buttons */}
        <View style={styles.btns}>
          <TouchableOpacity
            style={[styles.selectBtn, { backgroundColor: colors.primary }]}
            onPress={() => router.push('/courses' as any)}
            activeOpacity={0.85}
          >
            <Text style={styles.selectBtnText}>{t.locker.selectBtn}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.reserveBtn, { borderColor: colors.border }]}
            onPress={handleReserve}
            activeOpacity={0.85}
          >
            <Text style={[styles.reserveBtnText, { color: colors.muted }]}>
              {t.locker.reserveBtn}
            </Text>
          </TouchableOpacity>
        </View>

        <View style={[styles.reserveNote, { backgroundColor: '#FFF7ED' }]}>
          <Text style={[styles.reserveNoteText, { color: '#C2410C' }]}>
            {t.locker.reserveNote}
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function InfoCard({
  title,
  colors,
  children,
}: {
  title: string;
  colors: any;
  children: React.ReactNode;
}) {
  return (
    <View style={[cardStyles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <Text style={[cardStyles.title, { color: colors.foreground }]}>{title}</Text>
      {children}
    </View>
  );
}

const cardStyles = StyleSheet.create({
  card: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    marginBottom: 16,
  },
  title: {
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 12,
  },
});

const styles = StyleSheet.create({
  scroll: {
    padding: 20,
    paddingBottom: 40,
  },
  empty: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 16,
  },
  emptyText: { fontSize: 16 },
  retryText: { fontSize: 16, fontWeight: '600' },
  header: { marginBottom: 20 },
  backBtn: { marginBottom: 8 },
  backText: { fontSize: 15, fontWeight: '500' },
  title: { fontSize: 24, fontWeight: '800', letterSpacing: -0.5 },
  mapPlaceholder: {
    borderRadius: 16,
    height: 160,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    position: 'relative',
  },
  mapEmoji: { fontSize: 40, marginBottom: 8 },
  mapText: { fontSize: 13 },
  mapPin: {
    position: 'absolute',
    top: '40%',
    left: '50%',
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mapPinText: { fontSize: 20 },
  nameCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    marginBottom: 16,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    marginBottom: 8,
    flexWrap: 'wrap',
  },
  lockerName: { fontSize: 16, fontWeight: '700', flex: 1 },
  statusBadge: { borderRadius: 10, paddingHorizontal: 8, paddingVertical: 3 },
  statusText: { fontSize: 12, fontWeight: '600' },
  address: { fontSize: 13, lineHeight: 20, color: '#64748B' },
  sizeGrid: { flexDirection: 'row', gap: 10 },
  sizeItem: {
    flex: 1,
    borderRadius: 12,
    borderWidth: 1,
    padding: 12,
    alignItems: 'center',
    gap: 4,
  },
  sizeEmoji: { fontSize: 24 },
  sizeLabel: { fontSize: 13, fontWeight: '600' },
  sizeCheck: { fontSize: 16, fontWeight: '700' },
  feeGrid: { flexDirection: 'row', gap: 8, marginBottom: 8 },
  feeItem: {
    flex: 1,
    borderRadius: 10,
    padding: 10,
    alignItems: 'center',
    gap: 4,
  },
  feeLabel: { fontSize: 12 },
  feeValue: { fontSize: 13, fontWeight: '700' },
  feeNote: { fontSize: 11, lineHeight: 16 },
  travelRow: { flexDirection: 'row', gap: 12 },
  travelItem: {
    flex: 1,
    borderRadius: 12,
    padding: 14,
    alignItems: 'center',
    gap: 4,
  },
  travelNum: { fontSize: 22, fontWeight: '800' },
  travelLabel: { fontSize: 12 },
  reasonCard: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 14,
    marginBottom: 16,
  },
  reasonTitle: { fontSize: 14, fontWeight: '700', marginBottom: 6 },
  reasonText: { fontSize: 14, lineHeight: 21 },
  routeItem: {
    borderRadius: 10,
    borderWidth: 1,
    padding: 12,
    marginBottom: 10,
  },
  routeHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  routeType: { fontSize: 14, fontWeight: '600' },
  diffBadge: { borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 },
  diffText: { fontSize: 12, fontWeight: '600' },
  routeInfo: { flexDirection: 'row', gap: 12, flexWrap: 'wrap' },
  routeInfoText: { fontSize: 13 },
  routeDetailBtn: {
    borderRadius: 10,
    borderWidth: 1,
    padding: 10,
    alignItems: 'center',
  },
  routeDetailBtnText: { fontSize: 14, fontWeight: '600' },
  btns: { gap: 10, marginBottom: 12 },
  selectBtn: {
    borderRadius: 16,
    paddingVertical: 18,
    alignItems: 'center',
  },
  selectBtnText: { color: '#FFFFFF', fontSize: 17, fontWeight: '700' },
  reserveBtn: {
    borderRadius: 16,
    borderWidth: 1,
    paddingVertical: 14,
    alignItems: 'center',
  },
  reserveBtnText: { fontSize: 14, fontWeight: '500' },
  reserveNote: {
    borderRadius: 10,
    padding: 12,
    marginBottom: 8,
  },
  reserveNoteText: { fontSize: 12, lineHeight: 18 },
});
