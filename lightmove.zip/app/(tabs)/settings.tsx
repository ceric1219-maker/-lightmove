import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Switch,
} from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useApp } from '@/lib/AppContext';
import { useColors } from '@/hooks/use-colors';
import { useColorScheme } from '@/hooks/use-color-scheme';

export default function SettingsScreen() {
  const { t, language, setLanguage, timeFormat24h, setTimeFormat24h, reset } = useApp();
  const colors = useColors();
  const colorScheme = useColorScheme();

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={[styles.title, { color: colors.foreground }]}>{t.settings.title}</Text>
        </View>

        {/* Language */}
        <SettingSection title={t.settings.language} colors={colors}>
          <View style={styles.langBtns}>
            {[
              { key: 'ko', label: '한국어' },
              { key: 'en', label: 'English' },
            ].map((l) => (
              <TouchableOpacity
                key={l.key}
                style={[
                  styles.langBtn,
                  {
                    backgroundColor: language === l.key ? colors.primary : colors.surface,
                    borderColor: language === l.key ? colors.primary : colors.border,
                  },
                ]}
                onPress={() => setLanguage(l.key as 'ko' | 'en')}
              >
                <Text style={[
                  styles.langBtnText,
                  { color: language === l.key ? '#FFFFFF' : colors.foreground },
                ]}>
                  {l.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </SettingSection>

        {/* Time Format */}
        <SettingSection title={t.settings.timeFormat} colors={colors}>
          <View style={styles.switchRow}>
            <Text style={[styles.switchLabel, { color: colors.foreground }]}>
              {timeFormat24h
                ? (language === 'ko' ? '24시간 형식 (14:30)' : '24-hour format (14:30)')
                : (language === 'ko' ? '12시간 형식 (2:30 PM)' : '12-hour format (2:30 PM)')}
            </Text>
            <Switch
              value={timeFormat24h}
              onValueChange={setTimeFormat24h}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor="#FFFFFF"
            />
          </View>
        </SettingSection>

        {/* Theme */}
        <SettingSection title={language === 'ko' ? '테마' : 'Theme'} colors={colors}>
          <View style={[styles.themeInfo, { backgroundColor: colors.background }]}>
            <Text style={styles.themeIcon}>
              {colorScheme === 'dark' ? '🌙' : '☀️'}
            </Text>
            <Text style={[styles.themeText, { color: colors.foreground }]}>
              {colorScheme === 'dark'
                ? (language === 'ko' ? '다크 모드 (시스템 설정)' : 'Dark Mode (System)')
                : (language === 'ko' ? '라이트 모드 (시스템 설정)' : 'Light Mode (System)')}
            </Text>
          </View>
          <Text style={[styles.themeNote, { color: colors.muted }]}>
            {language === 'ko'
              ? '테마는 기기 시스템 설정을 따릅니다'
              : 'Theme follows device system settings'}
          </Text>
        </SettingSection>

        {/* App Info */}
        <SettingSection title={t.settings.appInfo} colors={colors}>
          {[
            {
              labelKo: '앱 이름',
              labelEn: 'App Name',
              value: t.appName,
            },
            {
              labelKo: '버전',
              labelEn: 'Version',
              value: '1.0.0 (Demo)',
            },
            {
              labelKo: '데이터 출처',
              labelEn: 'Data Source',
              value: language === 'ko' ? '샘플 데이터 (공공데이터 API 연동 예정)' : 'Sample data (Public API integration planned)',
            },
            {
              labelKo: '서비스 권역',
              labelEn: 'Service Areas',
              value: language === 'ko' ? '서울역, 홍대입구, 명동' : 'Seoul Stn, Hongik, Myeongdong',
            },
          ].map((item, i) => (
            <View key={i} style={[styles.infoRow, { borderBottomColor: colors.border }]}>
              <Text style={[styles.infoLabel, { color: colors.muted }]}>
                {language === 'ko' ? item.labelKo : item.labelEn}
              </Text>
              <Text style={[styles.infoValue, { color: colors.foreground }]}>
                {item.value}
              </Text>
            </View>
          ))}
        </SettingSection>

        {/* Data Note */}
        <View style={[styles.dataNote, { backgroundColor: '#FFF7ED', borderColor: '#F97316' }]}>
          <Text style={styles.dataNoteIcon}>⚠️</Text>
          <Text style={[styles.dataNoteText, { color: '#92400E' }]}>
            {t.dataNote}
          </Text>
        </View>

        {/* Reset */}
        <SettingSection title={language === 'ko' ? '데이터 초기화' : 'Reset Data'} colors={colors}>
          <TouchableOpacity
            style={[styles.resetBtn, { borderColor: colors.error }]}
            onPress={reset}
            activeOpacity={0.85}
          >
            <Text style={[styles.resetBtnText, { color: colors.error }]}>
              {language === 'ko' ? '🔄 추천 데이터 초기화' : '🔄 Reset Recommendation Data'}
            </Text>
          </TouchableOpacity>
          <Text style={[styles.resetNote, { color: colors.muted }]}>
            {language === 'ko'
              ? '현재 추천 결과와 선택 항목이 초기화됩니다'
              : 'Current results and selections will be cleared'}
          </Text>
        </SettingSection>

        {/* Credits */}
        <View style={styles.credits}>
          <Text style={[styles.creditsText, { color: colors.muted }]}>
            {language === 'ko'
              ? '라이트무브 — 체크인 전·후 반나절 여행 도우미'
              : 'Light Move — Half-day travel guide before/after check-in'}
          </Text>
          <Text style={[styles.creditsNote, { color: colors.muted }]}>
            {language === 'ko'
              ? '현재 데모 버전입니다. 실제 서비스는 공공데이터 API와 연동됩니다.'
              : 'This is a demo version. Real service will integrate with public data APIs.'}
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function SettingSection({
  title,
  colors,
  children,
}: {
  title: string;
  colors: any;
  children: React.ReactNode;
}) {
  return (
    <View style={[sectionStyles.container, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <Text style={[sectionStyles.title, { color: colors.foreground }]}>{title}</Text>
      {children}
    </View>
  );
}

const sectionStyles = StyleSheet.create({
  container: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    marginBottom: 16,
  },
  title: {
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
});

const styles = StyleSheet.create({
  scroll: { padding: 20, paddingBottom: 40 },
  header: { marginBottom: 20 },
  title: { fontSize: 22, fontWeight: '800', letterSpacing: -0.5 },
  langBtns: { flexDirection: 'row', gap: 10 },
  langBtn: {
    flex: 1,
    borderRadius: 12,
    borderWidth: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  langBtnText: { fontSize: 15, fontWeight: '600' },
  switchRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  switchLabel: { fontSize: 14, flex: 1 },
  themeInfo: {
    borderRadius: 10,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 8,
  },
  themeIcon: { fontSize: 24 },
  themeText: { fontSize: 14, fontWeight: '500' },
  themeNote: { fontSize: 12 },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 0.5,
    gap: 12,
  },
  infoLabel: { fontSize: 13 },
  infoValue: { fontSize: 13, fontWeight: '500', flex: 1, textAlign: 'right' },
  dataNote: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 14,
    flexDirection: 'row',
    gap: 10,
    marginBottom: 16,
  },
  dataNoteIcon: { fontSize: 18 },
  dataNoteText: { flex: 1, fontSize: 12, lineHeight: 18 },
  resetBtn: {
    borderRadius: 12,
    borderWidth: 1,
    paddingVertical: 12,
    alignItems: 'center',
    marginBottom: 8,
  },
  resetBtnText: { fontSize: 14, fontWeight: '600' },
  resetNote: { fontSize: 12 },
  credits: { alignItems: 'center', gap: 4, paddingTop: 8 },
  creditsText: { fontSize: 13, fontWeight: '600', textAlign: 'center' },
  creditsNote: { fontSize: 11, textAlign: 'center', lineHeight: 16 },
});
