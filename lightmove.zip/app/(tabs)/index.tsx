import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Image,
} from 'react-native';
import { router } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useApp } from '@/lib/AppContext';
import { useColors } from '@/hooks/use-colors';

export default function HomeScreen() {
  const { t, language, setLanguage, onboardingDone, recommendResult } = useApp();
  const colors = useColors();

  const handleStart = () => {
    if (!onboardingDone) {
      router.push('/onboarding' as any);
    } else {
      router.push('/situation' as any);
    }
  };

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.logoRow}>
            <Image
              source={require('@/assets/images/icon.png')}
              style={styles.logo}
              resizeMode="contain"
            />
            <View>
              <Text style={[styles.appName, { color: colors.foreground }]}>{t.appName}</Text>
              <Text style={[styles.appTagline, { color: colors.muted }]}>{t.appTagline}</Text>
            </View>
          </View>
          <TouchableOpacity
            style={[styles.langBtn, { borderColor: colors.border, backgroundColor: colors.surface }]}
            onPress={() => setLanguage(language === 'ko' ? 'en' : 'ko')}
          >
            <Text style={[styles.langText, { color: colors.primary }]}>
              {language === 'ko' ? '한 / EN' : 'KO / EN'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Hero Banner */}
        <View style={[styles.heroBanner, { backgroundColor: colors.primary }]}>
          <Text style={styles.heroSlogan}>{t.appSlogan}</Text>
          <TouchableOpacity
            style={styles.heroBtn}
            onPress={handleStart}
            activeOpacity={0.85}
          >
            <Text style={[styles.heroBtnText, { color: colors.primary }]}>
              {language === 'ko' ? '지금 시작하기 →' : 'Start Now →'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Previous result shortcut */}
        {recommendResult && (
          <TouchableOpacity
            style={[styles.prevResult, { backgroundColor: '#F0FDF4', borderColor: '#10B981' }]}
            onPress={() => router.push('/result' as any)}
            activeOpacity={0.85}
          >
            <Text style={styles.prevResultIcon}>📋</Text>
            <View style={styles.prevResultContent}>
              <Text style={[styles.prevResultTitle, { color: '#166534' }]}>
                {language === 'ko' ? '이전 추천 결과 보기' : 'View Previous Results'}
              </Text>
              <Text style={[styles.prevResultSub, { color: '#4ADE80' }]}>
                {language === 'ko'
                  ? `자유시간 ${Math.floor(recommendResult.freeTimeCalc.freeTimeMin / 60)}시간 ${recommendResult.freeTimeCalc.freeTimeMin % 60}분`
                  : `Free time: ${Math.floor(recommendResult.freeTimeCalc.freeTimeMin / 60)}h ${recommendResult.freeTimeCalc.freeTimeMin % 60}m`}
              </Text>
            </View>
            <Text style={[styles.prevResultArrow, { color: '#10B981' }]}>→</Text>
          </TouchableOpacity>
        )}

        {/* Feature cards */}
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          {language === 'ko' ? '주요 기능' : 'Key Features'}
        </Text>
        <View style={styles.featureGrid}>
          {[
            {
              icon: '📦',
              titleKo: '짐 보관함 추천',
              titleEn: 'Luggage Storage',
              descKo: '공영 보관함 3곳 추천\n크기별 맞춤 안내',
              descEn: '3 public locker options\nSize-matched recommendations',
              color: '#EFF6FF',
              accent: colors.primary,
              onPress: () => router.push('/(tabs)/lockers' as any),
            },
            {
              icon: '🗺️',
              titleKo: '편한 이동 경로',
              titleEn: 'Easy Routes',
              descKo: '엘리베이터 우선\n계단 최소 경로',
              descEn: 'Elevator-first\nMinimal stairs',
              color: '#F0FDF4',
              accent: '#10B981',
              onPress: () => router.push('/situation' as any),
            },
            {
              icon: '⏱️',
              titleKo: '자유시간 계산',
              titleEn: 'Free Time Calc',
              descKo: '보관~복귀 시간\n자동 계산',
              descEn: 'Store-to-return\nauto calculation',
              color: '#FFF7ED',
              accent: '#F97316',
              onPress: () => router.push('/situation' as any),
            },
            {
              icon: '🎯',
              titleKo: '반나절 코스',
              titleEn: 'Half-Day Plans',
              descKo: '시간·선호 맞춤\n코스 2~3개 추천',
              descEn: 'Time & preference\n2-3 course options',
              color: '#F5F3FF',
              accent: '#7C3AED',
              onPress: () => router.push('/(tabs)/explore' as any),
            },
          ].map((f, i) => (
            <TouchableOpacity
              key={i}
              style={[styles.featureCard, { backgroundColor: f.color, borderColor: f.accent + '30' }]}
              onPress={f.onPress}
              activeOpacity={0.85}
            >
              <Text style={styles.featureIcon}>{f.icon}</Text>
              <Text style={[styles.featureTitle, { color: f.accent }]}>
                {language === 'ko' ? f.titleKo : f.titleEn}
              </Text>
              <Text style={[styles.featureDesc, { color: colors.muted }]}>
                {language === 'ko' ? f.descKo : f.descEn}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Demo zones */}
        <View style={[styles.zonesCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.zonesTitle, { color: colors.foreground }]}>
            📍 {language === 'ko' ? '시범 운영 권역' : 'Demo Service Areas'}
          </Text>
          {[
            { name: language === 'ko' ? '서울역 권역' : 'Seoul Station Area', emoji: '🚂' },
            { name: language === 'ko' ? '홍대입구역 권역' : 'Hongik Univ. Station Area', emoji: '🎨' },
            { name: language === 'ko' ? '명동 권역' : 'Myeongdong Area', emoji: '🛍️' },
          ].map((z, i) => (
            <View key={i} style={styles.zoneRow}>
              <Text style={styles.zoneEmoji}>{z.emoji}</Text>
              <Text style={[styles.zoneName, { color: colors.foreground }]}>{z.name}</Text>
              <View style={[styles.zoneBadge, { backgroundColor: '#DCFCE7' }]}>
                <Text style={[styles.zoneBadgeText, { color: '#166534' }]}>
                  {language === 'ko' ? '운영 중' : 'Active'}
                </Text>
              </View>
            </View>
          ))}
        </View>

        {/* CTA */}
        <TouchableOpacity
          style={[styles.ctaBtn, { backgroundColor: colors.primary }]}
          onPress={handleStart}
          activeOpacity={0.85}
        >
          <Text style={styles.ctaBtnText}>
            {language === 'ko' ? '🧳 지금 짐 맡기고 여행 시작' : '🧳 Store Luggage & Start Exploring'}
          </Text>
        </TouchableOpacity>

        {/* Data note */}
        <Text style={[styles.dataNote, { color: colors.muted }]}>{t.dataNote}</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: { padding: 20, paddingBottom: 40 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  logoRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  logo: { width: 40, height: 40, borderRadius: 10 },
  appName: { fontSize: 18, fontWeight: '800', letterSpacing: -0.5 },
  appTagline: { fontSize: 11 },
  langBtn: {
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  langText: { fontSize: 13, fontWeight: '600' },
  heroBanner: {
    borderRadius: 20,
    padding: 24,
    marginBottom: 16,
  },
  heroSlogan: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '700',
    lineHeight: 28,
    marginBottom: 16,
    textAlign: 'center',
  },
  heroBtn: {
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
  },
  heroBtnText: { fontSize: 16, fontWeight: '700' },
  prevResult: {
    borderRadius: 14,
    borderWidth: 1.5,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 20,
  },
  prevResultIcon: { fontSize: 24 },
  prevResultContent: { flex: 1 },
  prevResultTitle: { fontSize: 14, fontWeight: '700', marginBottom: 2 },
  prevResultSub: { fontSize: 12 },
  prevResultArrow: { fontSize: 18, fontWeight: '700' },
  sectionTitle: { fontSize: 16, fontWeight: '700', marginBottom: 12 },
  featureGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 20,
  },
  featureCard: {
    width: '47%',
    borderRadius: 14,
    borderWidth: 1,
    padding: 14,
    gap: 6,
  },
  featureIcon: { fontSize: 28 },
  featureTitle: { fontSize: 14, fontWeight: '700' },
  featureDesc: { fontSize: 12, lineHeight: 18 },
  zonesCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    marginBottom: 20,
  },
  zonesTitle: { fontSize: 15, fontWeight: '700', marginBottom: 12 },
  zoneRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 10,
  },
  zoneEmoji: { fontSize: 20 },
  zoneName: { flex: 1, fontSize: 14 },
  zoneBadge: { borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 },
  zoneBadgeText: { fontSize: 12, fontWeight: '600' },
  ctaBtn: {
    borderRadius: 16,
    paddingVertical: 18,
    alignItems: 'center',
    marginBottom: 16,
  },
  ctaBtnText: { color: '#FFFFFF', fontSize: 17, fontWeight: '700' },
  dataNote: { fontSize: 11, textAlign: 'center', lineHeight: 16 },
});
