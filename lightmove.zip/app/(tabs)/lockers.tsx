import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  StyleSheet,
} from 'react-native';
import { router } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useApp } from '@/lib/AppContext';
import { useColors } from '@/hooks/use-colors';
import { lockers } from '@/lib/sampleData';
import type { Locker } from '@/lib/sampleData';

export default function LockersScreen() {
  const { t, language, setSelectedLocker } = useApp();
  const colors = useColors();
  const [selectedZone, setSelectedZone] = useState<string>('all');

  const zones = [
    { key: 'all', ko: '전체', en: 'All' },
    { key: 'seoul', ko: '서울역', en: 'Seoul Stn' },
    { key: 'hongik', ko: '홍대', en: 'Hongik' },
    { key: 'myeongdong', ko: '명동', en: 'Myeongdong' },
  ];

  const filtered = selectedZone === 'all'
    ? lockers
    : lockers.filter((l) => l.zone === selectedZone);

  const handleSelect = (locker: Locker) => {
    setSelectedLocker(locker);
    router.push('/locker-detail' as any);
  };

  const renderLocker = ({ item, index }: { item: Locker; index: number }) => (
    <TouchableOpacity
      style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}
      onPress={() => handleSelect(item)}
      activeOpacity={0.85}
    >
      <View style={styles.cardHeader}>
        <View style={styles.nameRow}>
          <Text style={[styles.lockerName, { color: colors.foreground }]}>
            {language === 'ko' ? item.name : item.nameEn}
          </Text>
          <View style={[
            styles.availBadge,
            { backgroundColor: item.available ? '#DCFCE7' : '#FEE2E2' },
          ]}>
            <Text style={[
              styles.availText,
              { color: item.available ? '#166534' : '#991B1B' },
            ]}>
              {item.available ? t.result.available : t.result.unavailable}
            </Text>
          </View>
        </View>
        <Text style={[styles.location, { color: colors.muted }]}>
          📍 {language === 'ko' ? item.location : item.locationEn}
        </Text>
      </View>

      <View style={styles.infoRow}>
        <InfoChip icon="🚶" label={`${item.travelMinutes}${language === 'ko' ? '분' : 'min'}`} colors={colors} />
        <InfoChip icon="💰" label={`${item.feePerHour.medium.toLocaleString()}${t.locker.perHour}`} colors={colors} />
        <InfoChip
          icon={item.returnEase === 'good' ? '⭐' : item.returnEase === 'ok' ? '🔸' : '🔺'}
          label={
            language === 'ko'
              ? item.returnEase === 'good' ? '복귀 우수' : item.returnEase === 'ok' ? '복귀 양호' : '복귀 불편'
              : item.returnEase === 'good' ? 'Return: Good' : item.returnEase === 'ok' ? 'Return: OK' : 'Return: Poor'
          }
          colors={colors}
        />
      </View>

      <View style={styles.sizes}>
        {(['small', 'medium', 'large'] as const).map((s) => (
          <View
            key={s}
            style={[
              styles.sizeBadge,
              {
                backgroundColor: item.sizes[s] ? colors.primary + '15' : colors.border + '30',
                borderColor: item.sizes[s] ? colors.primary : colors.border,
              },
            ]}
          >
            <Text style={[
              styles.sizeBadgeText,
              { color: item.sizes[s] ? colors.primary : colors.muted },
            ]}>
              {t.result.lockerSize[s]} {item.sizes[s] ? '✓' : '✗'}
            </Text>
          </View>
        ))}
      </View>

      <Text style={[styles.viewDetail, { color: colors.primary }]}>
        {language === 'ko' ? '상세 보기 →' : 'View Details →'}
      </Text>
    </TouchableOpacity>
  );

  return (
    <ScreenContainer>
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={[styles.title, { color: colors.foreground }]}>{t.tabs.lockers}</Text>
          <Text style={[styles.subtitle, { color: colors.muted }]}>
            {language === 'ko' ? `총 ${filtered.length}개 보관함` : `${filtered.length} lockers`}
          </Text>
        </View>

        {/* Zone filter */}
        <View style={styles.zoneFilter}>
          {zones.map((z) => (
            <TouchableOpacity
              key={z.key}
              style={[
                styles.zoneChip,
                {
                  backgroundColor: selectedZone === z.key ? colors.primary : colors.surface,
                  borderColor: selectedZone === z.key ? colors.primary : colors.border,
                },
              ]}
              onPress={() => setSelectedZone(z.key)}
            >
              <Text style={[
                styles.zoneChipText,
                { color: selectedZone === z.key ? '#FFFFFF' : colors.foreground },
              ]}>
                {language === 'ko' ? z.ko : z.en}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* List */}
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.id}
          renderItem={renderLocker}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
        />
      </View>
    </ScreenContainer>
  );
}

function InfoChip({ icon, label, colors }: { icon: string; label: string; colors: any }) {
  return (
    <View style={chipStyles.chip}>
      <Text style={chipStyles.icon}>{icon}</Text>
      <Text style={[chipStyles.label, { color: colors.muted }]}>{label}</Text>
    </View>
  );
}

const chipStyles = StyleSheet.create({
  chip: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  icon: { fontSize: 13 },
  label: { fontSize: 13 },
});

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 12 },
  title: { fontSize: 22, fontWeight: '800', letterSpacing: -0.5 },
  subtitle: { fontSize: 13, marginTop: 2 },
  zoneFilter: {
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 20,
    paddingBottom: 12,
  },
  zoneChip: {
    borderRadius: 20,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 7,
  },
  zoneChipText: { fontSize: 13, fontWeight: '600' },
  list: { paddingHorizontal: 20, paddingBottom: 20 },
  card: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    marginBottom: 14,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 1,
  },
  cardHeader: { marginBottom: 10 },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
    flexWrap: 'wrap',
  },
  lockerName: { fontSize: 15, fontWeight: '700', flex: 1 },
  availBadge: { borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 },
  availText: { fontSize: 12, fontWeight: '600' },
  location: { fontSize: 13 },
  infoRow: { flexDirection: 'row', gap: 14, marginBottom: 10, flexWrap: 'wrap' },
  sizes: { flexDirection: 'row', gap: 8, marginBottom: 10 },
  sizeBadge: { borderRadius: 8, borderWidth: 1, paddingHorizontal: 10, paddingVertical: 4 },
  sizeBadgeText: { fontSize: 12, fontWeight: '600' },
  viewDetail: { fontSize: 13, fontWeight: '600', textAlign: 'right' },
});
