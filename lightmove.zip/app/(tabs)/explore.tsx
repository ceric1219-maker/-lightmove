import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  StyleSheet,
} from 'react-native';
import { router } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useApp } from '@/lib/AppContext';
import { useColors } from '@/hooks/use-colors';
import { courses } from '@/lib/sampleData';
import type { Course } from '@/lib/sampleData';
import { formatDuration } from '@/lib/recommendEngine';

export default function ExploreScreen() {
  const { t, language, setSelectedCourse } = useApp();
  const colors = useColors();
  const [filter, setFilter] = useState<'all' | 'indoor' | 'outdoor' | 'meal'>('all');

  const filtered = courses.filter((c) => {
    if (filter === 'indoor') return c.indoor;
    if (filter === 'outdoor') return !c.indoor;
    if (filter === 'meal') return c.includesMeal;
    return true;
  });

  const handleSelect = (course: Course) => {
    setSelectedCourse(course);
    router.push('/summary' as any);
  };

  const getDiffColor = (diff: string) => {
    if (diff === 'easy') return { bg: '#DCFCE7', text: '#166534' };
    if (diff === 'medium') return { bg: '#FEF9C3', text: '#854D0E' };
    return { bg: '#FEE2E2', text: '#991B1B' };
  };

  const getDiffLabel = (diff: string) => {
    if (diff === 'easy') return t.route.easy;
    if (diff === 'medium') return t.route.medium;
    return t.route.hard;
  };

  const renderCourse = ({ item }: { item: Course }) => {
    const diffColors = getDiffColor(item.difficulty);
    return (
      <TouchableOpacity
        style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}
        onPress={() => handleSelect(item)}
        activeOpacity={0.85}
      >
        <View style={styles.cardTop}>
          <View style={styles.cardTopLeft}>
            <Text style={[styles.courseName, { color: colors.foreground }]}>
              {language === 'ko' ? item.name : item.nameEn}
            </Text>
            <Text style={[styles.courseDesc, { color: colors.muted }]}>
              {language === 'ko' ? item.description : item.descriptionEn}
            </Text>
          </View>
          <View style={styles.cardTopRight}>
            <View style={[styles.durationBadge, { backgroundColor: colors.primary + '15' }]}>
              <Text style={[styles.durationText, { color: colors.primary }]}>
                ⏱ {formatDuration(item.totalMinutes, language as 'ko' | 'en')}
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.badges}>
          <View style={[styles.diffBadge, { backgroundColor: diffColors.bg }]}>
            <Text style={[styles.diffText, { color: diffColors.text }]}>
              {getDiffLabel(item.difficulty)}
            </Text>
          </View>
          <View style={[styles.typeBadge, { backgroundColor: item.indoor ? '#EFF6FF' : '#F0FDF4' }]}>
            <Text style={[styles.typeText, { color: item.indoor ? colors.primary : '#166534' }]}>
              {item.indoor ? `🏠 ${t.course.indoor}` : `🌿 ${t.course.outdoor}`}
            </Text>
          </View>
          {item.includesMeal && (
            <View style={[styles.mealBadge, { backgroundColor: '#FFF7ED' }]}>
              <Text style={[styles.mealText, { color: '#C2410C' }]}>
                🍽️ {language === 'ko' ? '식사 포함' : 'Meal'}
              </Text>
            </View>
          )}
        </View>

        <View style={styles.tags}>
          {item.tags.slice(0, 3).map((tag, i) => (
            <View key={i} style={[styles.tag, { backgroundColor: colors.border + '50' }]}>
              <Text style={[styles.tagText, { color: colors.muted }]}>{tag}</Text>
            </View>
          ))}
        </View>

        <Text style={[styles.viewDetail, { color: colors.primary }]}>
          {language === 'ko' ? '이 코스로 요약 보기 →' : 'View Summary with This Course →'}
        </Text>
      </TouchableOpacity>
    );
  };

  return (
    <ScreenContainer>
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={[styles.title, { color: colors.foreground }]}>{t.tabs.courses}</Text>
          <Text style={[styles.subtitle, { color: colors.muted }]}>
            {language === 'ko' ? `${filtered.length}개 코스` : `${filtered.length} courses`}
          </Text>
        </View>

        {/* Filter */}
        <View style={styles.filterRow}>
          {[
            { key: 'all', ko: '전체', en: 'All' },
            { key: 'indoor', ko: '실내', en: 'Indoor' },
            { key: 'outdoor', ko: '야외', en: 'Outdoor' },
            { key: 'meal', ko: '식사 포함', en: 'With Meal' },
          ].map((f) => (
            <TouchableOpacity
              key={f.key}
              style={[
                styles.filterChip,
                {
                  backgroundColor: filter === f.key ? colors.primary : colors.surface,
                  borderColor: filter === f.key ? colors.primary : colors.border,
                },
              ]}
              onPress={() => setFilter(f.key as any)}
            >
              <Text style={[
                styles.filterChipText,
                { color: filter === f.key ? '#FFFFFF' : colors.foreground },
              ]}>
                {language === 'ko' ? f.ko : f.en}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* List */}
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.id}
          renderItem={renderCourse}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={[styles.empty, { backgroundColor: colors.surface }]}>
              <Text style={styles.emptyEmoji}>🗺️</Text>
              <Text style={[styles.emptyText, { color: colors.muted }]}>
                {language === 'ko' ? '해당 코스가 없습니다' : 'No courses found'}
              </Text>
            </View>
          }
        />
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 12 },
  title: { fontSize: 22, fontWeight: '800', letterSpacing: -0.5 },
  subtitle: { fontSize: 13, marginTop: 2 },
  filterRow: {
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 20,
    paddingBottom: 12,
    flexWrap: 'wrap',
  },
  filterChip: {
    borderRadius: 20,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 7,
  },
  filterChipText: { fontSize: 13, fontWeight: '600' },
  list: { paddingHorizontal: 20, paddingBottom: 20 },
  card: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    marginBottom: 14,
    gap: 10,
  },
  cardTop: { flexDirection: 'row', gap: 10 },
  cardTopLeft: { flex: 1, gap: 4 },
  cardTopRight: { alignItems: 'flex-end' },
  courseName: { fontSize: 15, fontWeight: '700' },
  courseDesc: { fontSize: 13, lineHeight: 19 },
  durationBadge: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 5 },
  durationText: { fontSize: 13, fontWeight: '600' },
  badges: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  diffBadge: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  diffText: { fontSize: 12, fontWeight: '600' },
  typeBadge: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  typeText: { fontSize: 12, fontWeight: '600' },
  mealBadge: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  mealText: { fontSize: 12, fontWeight: '600' },
  tags: { flexDirection: 'row', gap: 6, flexWrap: 'wrap' },
  tag: { borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 },
  tagText: { fontSize: 11 },
  viewDetail: { fontSize: 13, fontWeight: '600', textAlign: 'right' },
  empty: { borderRadius: 16, padding: 40, alignItems: 'center', gap: 12 },
  emptyEmoji: { fontSize: 40 },
  emptyText: { fontSize: 15 },
});
