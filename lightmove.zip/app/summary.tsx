import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Share,
} from 'react-native';
import { router } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useApp } from '@/lib/AppContext';
import { useColors } from '@/hooks/use-colors';
import { formatDuration, formatTime } from '@/lib/recommendEngine';

export default function SummaryScreen() {
  const { t, language, timeFormat24h, recommendResult, selectedLocker, selectedCourse, reset } = useApp();
  const colors = useColors();

  if (!recommendResult) {
    return (
      <ScreenContainer>
        <View style={styles.empty}>
          <Text style={[styles.emptyText, { color: colors.muted }]}>{t.common.error}</Text>
          <TouchableOpacity onPress={() => router.replace('/(tabs)')}>
            <Text style={[styles.retryText, { color: colors.primary }]}>{t.summary.restart}</Text>
          </TouchableOpacity>
        </View>
      </ScreenContainer>
    );
  }

  const { freeTimeCalc, recommendedLockers, recommendedCourses } = recommendResult;
  const locker = selectedLocker || recommendedLockers[0];
  const course = selectedCourse || recommendedCourses[0];

  const handleShare = async () => {
    try {
      const shareText = language === 'ko'
        ? `[라이트무브 여행 플랜]\n\n자유시간: ${formatDuration(freeTimeCalc.freeTimeMin, 'ko')}\n보관함: ${locker?.name || '-'}\n코스: ${course?.name || '-'}\n복귀 권장: ${formatTime(freeTimeCalc.suggestedReturnTime, timeFormat24h)}`
        : `[Light Move Travel Plan]\n\nFree Time: ${formatDuration(freeTimeCalc.freeTimeMin, 'en')}\nLocker: ${locker?.nameEn || '-'}\nCourse: ${course?.nameEn || '-'}\nReturn by: ${formatTime(freeTimeCalc.suggestedReturnTime, timeFormat24h)}`;
      await Share.share({ message: shareText });
    } catch (e) {
      // ignore
    }
  };

  const handleRestart = () => {
    reset();
    router.replace('/(tabs)');
  };

  const timelineItems = [
    {
      icon: '🚶',
      label: t.summary.moveToLocker,
      duration: freeTimeCalc.moveToLockerMin,
      color: colors.primary,
    },
    {
      icon: '📦',
      label: t.summary.storeLuggage,
      duration: freeTimeCalc.storeProcessMin,
      color: '#6366F1',
    },
    {
      icon: '🎯',
      label: t.summary.freeTour,
      duration: freeTimeCalc.freeTimeMin,
      color: '#10B981',
      highlight: true,
    },
    {
      icon: '🔙',
      label: t.summary.returnLocker,
      duration: freeTimeCalc.returnToLockerMin,
      color: '#F97316',
    },
    {
      icon: '✅',
      label: t.summary.nextSchedule,
      duration: freeTimeCalc.bufferMin,
      color: colors.muted,
    },
  ];

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={[styles.backText, { color: colors.primary }]}>← {t.common.back}</Text>
          </TouchableOpacity>
          <Text style={[styles.title, { color: colors.foreground }]}>{t.summary.title}</Text>
        </View>

        {/* Hero: Free Time */}
        <View style={[styles.heroCard, { backgroundColor: colors.primary }]}>
          <Text style={styles.heroLabel}>{t.summary.freeTime}</Text>
          <Text style={styles.heroTime}>
            {formatDuration(freeTimeCalc.freeTimeMin, language as 'ko' | 'en')}
          </Text>
          <View style={styles.heroReturn}>
            <Text style={styles.heroReturnIcon}>⚠️</Text>
            <Text style={styles.heroReturnText}>
              {t.summary.returnTime}: {formatTime(freeTimeCalc.suggestedReturnTime, timeFormat24h)}
            </Text>
          </View>
          <Text style={styles.heroReturnNote}>{t.summary.returnNote}</Text>
        </View>

        {/* Timeline */}
        <View style={[styles.timelineCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            📅 {t.summary.timeline}
          </Text>
          <View style={styles.timeline}>
            {timelineItems.map((item, i) => (
              <View key={i} style={styles.timelineRow}>
                <View style={[styles.timelineDot, { backgroundColor: item.color }]} />
                <Text style={styles.timelineIcon}>{item.icon}</Text>
                <Text style={[
                  styles.timelineLabel,
                  { color: item.highlight ? item.color : colors.foreground },
                  item.highlight && { fontWeight: '700' },
                ]}>
                  {item.label}
                </Text>
                <Text style={[
                  styles.timelineDuration,
                  { color: item.highlight ? item.color : colors.muted },
                  item.highlight && { fontWeight: '700' },
                ]}>
                  {formatDuration(item.duration, language as 'ko' | 'en')}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Recommended Locker */}
        {locker && (
          <View style={[styles.summaryCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={styles.summaryCardHeader}>
              <Text style={styles.summaryCardIcon}>📦</Text>
              <Text style={[styles.summaryCardTitle, { color: colors.foreground }]}>
                {t.summary.locker}
              </Text>
              <View style={[styles.availBadge, { backgroundColor: locker.available ? '#DCFCE7' : '#FEE2E2' }]}>
                <Text style={[styles.availText, { color: locker.available ? '#166534' : '#991B1B' }]}>
                  {locker.available ? t.result.available : t.result.unavailable}
                </Text>
              </View>
            </View>
            <Text style={[styles.summaryCardName, { color: colors.foreground }]}>
              {language === 'ko' ? locker.name : locker.nameEn}
            </Text>
            <Text style={[styles.summaryCardSub, { color: colors.muted }]}>
              📍 {language === 'ko' ? locker.location : locker.locationEn}
            </Text>
            <View style={styles.summaryCardInfo}>
              <Text style={[styles.summaryCardInfoText, { color: colors.muted }]}>
                🚶 {locker.travelMinutes}{language === 'ko' ? '분' : 'min'}
              </Text>
              <Text style={[styles.summaryCardInfoText, { color: colors.muted }]}>
                💰 {locker.feePerHour.medium.toLocaleString()}{t.locker.perHour}
              </Text>
            </View>
          </View>
        )}

        {/* Recommended Course */}
        {course && (
          <View style={[styles.summaryCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <View style={styles.summaryCardHeader}>
              <Text style={styles.summaryCardIcon}>🗺️</Text>
              <Text style={[styles.summaryCardTitle, { color: colors.foreground }]}>
                {t.summary.course}
              </Text>
              <View style={[styles.durationBadge, { backgroundColor: '#EFF6FF' }]}>
                <Text style={[styles.durationText, { color: colors.primary }]}>
                  {formatDuration(course.totalMinutes, language as 'ko' | 'en')}
                </Text>
              </View>
            </View>
            <Text style={[styles.summaryCardName, { color: colors.foreground }]}>
              {language === 'ko' ? course.name : course.nameEn}
            </Text>
            <Text style={[styles.summaryCardSub, { color: colors.muted }]}>
              {language === 'ko' ? course.description : course.descriptionEn}
            </Text>
            <View style={styles.summaryCardInfo}>
              <View style={[styles.indoorBadge, { backgroundColor: course.indoor ? '#EFF6FF' : '#F0FDF4' }]}>
                <Text style={[styles.indoorText, { color: course.indoor ? colors.primary : '#166534' }]}>
                  {course.indoor
                    ? `🏠 ${t.course.indoor}`
                    : `🌿 ${t.course.outdoor}`}
                </Text>
              </View>
              {course.includesMeal && (
                <View style={[styles.indoorBadge, { backgroundColor: '#FFF7ED' }]}>
                  <Text style={[styles.indoorText, { color: '#C2410C' }]}>
                    🍽️ {language === 'ko' ? '식사 포함' : 'Meal Included'}
                  </Text>
                </View>
              )}
            </View>
          </View>
        )}

        {/* Return time alert */}
        <View style={[styles.returnAlert, { backgroundColor: '#FFF7ED', borderColor: '#F97316' }]}>
          <Text style={styles.returnAlertTitle}>
            ⏰ {t.summary.returnTime}
          </Text>
          <Text style={[styles.returnAlertTime, { color: '#C2410C' }]}>
            {formatTime(freeTimeCalc.suggestedReturnTime, timeFormat24h)}
          </Text>
          <Text style={[styles.returnAlertNote, { color: '#92400E' }]}>
            {t.summary.returnNote}
          </Text>
        </View>

        {/* Action buttons */}
        <View style={styles.btns}>
          <TouchableOpacity
            style={[styles.shareBtn, { backgroundColor: '#6366F1' }]}
            onPress={handleShare}
            activeOpacity={0.85}
          >
            <Text style={styles.shareBtnText}>📤 {t.summary.share}</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.restartBtn, { borderColor: colors.border }]}
            onPress={handleRestart}
            activeOpacity={0.85}
          >
            <Text style={[styles.restartBtnText, { color: colors.foreground }]}>
              🔄 {t.summary.restart}
            </Text>
          </TouchableOpacity>
        </View>

        {/* Data note */}
        <Text style={[styles.dataNote, { color: colors.muted }]}>{t.dataNote}</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: { padding: 20, paddingBottom: 40 },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 16 },
  emptyText: { fontSize: 16 },
  retryText: { fontSize: 16, fontWeight: '600' },
  header: { marginBottom: 20 },
  backBtn: { marginBottom: 8 },
  backText: { fontSize: 15, fontWeight: '500' },
  title: { fontSize: 24, fontWeight: '800', letterSpacing: -0.5 },
  heroCard: {
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    marginBottom: 16,
  },
  heroLabel: { color: 'rgba(255,255,255,0.8)', fontSize: 14, marginBottom: 4 },
  heroTime: {
    color: '#FFFFFF',
    fontSize: 48,
    fontWeight: '900',
    letterSpacing: -2,
    marginBottom: 16,
  },
  heroReturn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 10,
    marginBottom: 8,
  },
  heroReturnIcon: { fontSize: 18 },
  heroReturnText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
  heroReturnNote: { color: 'rgba(255,255,255,0.7)', fontSize: 12 },
  timelineCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    marginBottom: 16,
  },
  sectionTitle: { fontSize: 16, fontWeight: '700', marginBottom: 16 },
  timeline: { gap: 14 },
  timelineRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  timelineDot: { width: 10, height: 10, borderRadius: 5 },
  timelineIcon: { fontSize: 18, width: 24, textAlign: 'center' },
  timelineLabel: { flex: 1, fontSize: 14 },
  timelineDuration: { fontSize: 14 },
  summaryCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    marginBottom: 16,
  },
  summaryCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 10,
  },
  summaryCardIcon: { fontSize: 20 },
  summaryCardTitle: { flex: 1, fontSize: 15, fontWeight: '700' },
  availBadge: { borderRadius: 10, paddingHorizontal: 8, paddingVertical: 3 },
  availText: { fontSize: 12, fontWeight: '600' },
  durationBadge: { borderRadius: 10, paddingHorizontal: 10, paddingVertical: 4 },
  durationText: { fontSize: 13, fontWeight: '600' },
  summaryCardName: { fontSize: 15, fontWeight: '700', marginBottom: 4 },
  summaryCardSub: { fontSize: 13, lineHeight: 19, marginBottom: 8 },
  summaryCardInfo: { flexDirection: 'row', gap: 10, flexWrap: 'wrap' },
  summaryCardInfoText: { fontSize: 13 },
  indoorBadge: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  indoorText: { fontSize: 12, fontWeight: '600' },
  returnAlert: {
    borderRadius: 16,
    borderWidth: 1.5,
    padding: 20,
    alignItems: 'center',
    marginBottom: 20,
  },
  returnAlertTitle: { fontSize: 14, color: '#92400E', marginBottom: 4 },
  returnAlertTime: { fontSize: 36, fontWeight: '900', letterSpacing: -1, marginBottom: 4 },
  returnAlertNote: { fontSize: 12, textAlign: 'center' },
  btns: { gap: 10, marginBottom: 16 },
  shareBtn: {
    borderRadius: 16,
    paddingVertical: 16,
    alignItems: 'center',
  },
  shareBtnText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
  restartBtn: {
    borderRadius: 16,
    borderWidth: 1,
    paddingVertical: 14,
    alignItems: 'center',
  },
  restartBtnText: { fontSize: 15, fontWeight: '600' },
  dataNote: { fontSize: 11, textAlign: 'center', lineHeight: 16 },
});
