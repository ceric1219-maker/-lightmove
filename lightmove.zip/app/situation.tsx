import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { router } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useApp } from '@/lib/AppContext';
import { useColors } from '@/hooks/use-colors';

export default function SituationScreen() {
  const { t, language, setLanguage } = useApp();
  const colors = useColors();

  const handleSelect = (situation: 'before-checkin' | 'after-checkout') => {
    router.push({ pathname: '/input' as any, params: { situation } });
  };

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={[styles.title, { color: colors.foreground }]}>
              {t.situation.title}
            </Text>
            <Text style={[styles.subtitle, { color: colors.muted }]}>
              {t.situation.subtitle}
            </Text>
          </View>
          {/* Language Toggle */}
          <TouchableOpacity
            style={[styles.langToggle, { borderColor: colors.border, backgroundColor: colors.surface }]}
            onPress={() => setLanguage(language === 'ko' ? 'en' : 'ko')}
          >
            <Text style={[styles.langText, { color: colors.primary }]}>
              {language === 'ko' ? '한 / EN' : 'KO / EN'}
            </Text>
          </TouchableOpacity>
        </View>

        {/* App branding */}
        <View style={[styles.brandCard, { backgroundColor: colors.primary }]}>
          <Text style={styles.brandSlogan}>{t.appSlogan}</Text>
        </View>

        {/* Situation Cards */}
        <View style={styles.cards}>
          {/* Before Check-in */}
          <TouchableOpacity
            style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}
            onPress={() => handleSelect('before-checkin')}
            activeOpacity={0.85}
          >
            <View style={[styles.cardIconBg, { backgroundColor: '#EFF6FF' }]}>
              <Text style={styles.cardIcon}>🏨</Text>
            </View>
            <View style={styles.cardContent}>
              <Text style={[styles.cardTitle, { color: colors.foreground }]}>
                {t.situation.checkinBefore}
              </Text>
              <Text style={[styles.cardDesc, { color: colors.muted }]}>
                {t.situation.checkinBeforeDesc}
              </Text>
            </View>
            <View style={[styles.cardArrow, { backgroundColor: colors.primary }]}>
              <Text style={styles.cardArrowText}>→</Text>
            </View>
          </TouchableOpacity>

          {/* After Check-out */}
          <TouchableOpacity
            style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}
            onPress={() => handleSelect('after-checkout')}
            activeOpacity={0.85}
          >
            <View style={[styles.cardIconBg, { backgroundColor: '#F0FDF4' }]}>
              <Text style={styles.cardIcon}>🧳</Text>
            </View>
            <View style={styles.cardContent}>
              <Text style={[styles.cardTitle, { color: colors.foreground }]}>
                {t.situation.checkoutAfter}
              </Text>
              <Text style={[styles.cardDesc, { color: colors.muted }]}>
                {t.situation.checkoutAfterDesc}
              </Text>
            </View>
            <View style={[styles.cardArrow, { backgroundColor: '#10B981' }]}>
              <Text style={styles.cardArrowText}>→</Text>
            </View>
          </TouchableOpacity>
        </View>

        {/* Features preview */}
        <View style={[styles.featuresCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.featuresTitle, { color: colors.foreground }]}>
            {language === 'ko' ? '이런 걸 도와드려요' : 'What we help with'}
          </Text>
          {[
            { icon: '📦', ko: '짐 보관함 추천 (3곳)', en: 'Luggage storage recommendations (3 options)' },
            { icon: '🗺️', ko: '짐 끌기 편한 이동 경로', en: 'Luggage-friendly routes' },
            { icon: '⏱️', ko: '자유시간 자동 계산', en: 'Automatic free time calculation' },
            { icon: '🎯', ko: '반나절 코스 추천', en: 'Half-day tour recommendations' },
          ].map((f, i) => (
            <View key={i} style={styles.featureRow}>
              <Text style={styles.featureIcon}>{f.icon}</Text>
              <Text style={[styles.featureText, { color: colors.muted }]}>
                {language === 'ko' ? f.ko : f.en}
              </Text>
            </View>
          ))}
        </View>

        {/* Data note */}
        <Text style={[styles.dataNote, { color: colors.muted }]}>{t.dataNote}</Text>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: {
    padding: 20,
    paddingBottom: 40,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    letterSpacing: -0.5,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
  },
  langToggle: {
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 7,
  },
  langText: {
    fontSize: 13,
    fontWeight: '600',
  },
  brandCard: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  brandSlogan: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    lineHeight: 24,
    textAlign: 'center',
  },
  cards: {
    gap: 16,
    marginBottom: 24,
  },
  card: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  cardIconBg: {
    width: 56,
    height: 56,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardIcon: {
    fontSize: 28,
  },
  cardContent: {
    flex: 1,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  cardDesc: {
    fontSize: 13,
    lineHeight: 19,
  },
  cardArrow: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardArrowText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
  featuresCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 20,
    marginBottom: 16,
  },
  featuresTitle: {
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 14,
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 10,
  },
  featureIcon: {
    fontSize: 20,
    width: 28,
    textAlign: 'center',
  },
  featureText: {
    fontSize: 14,
    lineHeight: 20,
  },
  dataNote: {
    fontSize: 11,
    textAlign: 'center',
    lineHeight: 16,
  },
});
