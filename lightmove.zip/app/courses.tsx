import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';
import { router } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useApp } from '@/lib/AppContext';
import { useColors } from '@/hooks/use-colors';
import { formatDuration } from '@/lib/recommendEngine';
import type { Course } from '@/lib/sampleData';

export default function CoursesScreen() {
  const { t, language: langRaw, recommendResult, setSelectedCourse } = useApp();
  const language = langRaw as 'ko' | 'en';
  const colors = useColors();

  const courses = recommendResult?.recommendedCourses || [];

  const handleSelectCourse = (course: Course) => {
    setSelectedCourse(course);
    router.push('/summary' as any);
  };

  const getDiffColor = (diff: string) => {
    if (diff === 'easy') return { bg: '#DCFCE7', text: '#166534' };
    if (diff === 'medium') return { bg: '#FEF9C3', text: '#854D0E' };
    return { bg: '#FEE2E2', text: '#991B1B' };
  };

  const getDiffLabel = (diff: string) => {
    if (diff === 'easy') return t.route.easy;
    if (diff === 'medium') return t.route.medium;
    return t.route.hard;
  };

  const courseColors = ['#2563EB', '#10B981', '#F97316'];

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={[styles.backText, { color: colors.primary }]}>← {t.common.back}</Text>
          </TouchableOpacity>
          <Text style={[styles.title, { color: colors.foreground }]}>{t.course.title}</Text>
          <Text style={[styles.subtitle, { color: colors.muted }]}>{t.course.subtitle}</Text>
        </View>

        {/* Free time reminder */}
        {recommendResult && (
          <View style={[styles.freeTimeReminder, { backgroundColor: colors.primary + '15', borderColor: colors.primary + '30' }]}>
            <Text style={[styles.freeTimeText, { color: colors.primary }]}>
              ⏱️ {language === 'ko' ? '자유시간' : 'Free Time'}:{' '}
              <Text style={styles.freeTimeBold}>
                {formatDuration(recommendResult.freeTimeCalc.freeTimeMin, language)}
              </Text>
            </Text>
          </View>
        )}

        {/* Course cards */}
        {courses.length > 0 ? (
          courses.map((course, index) => (
            <CourseCard
              key={course.id}
              course={course}
              index={index}
              language={language}
              t={t}
              colors={colors}
              accentColor={courseColors[index] || colors.primary}
              getDiffColor={getDiffColor}
              getDiffLabel={getDiffLabel}
              onSelect={() => handleSelectCourse(course)}
            />
          ))
        ) : (
          <View style={[styles.empty, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={styles.emptyEmoji}>🗺️</Text>
            <Text style={[styles.emptyText, { color: colors.muted }]}>
              {language === 'ko' ? '추천 코스가 없습니다' : 'No courses available'}
            </Text>
          </View>
        )}

        {/* Data note */}
        <View style={[styles.dataNote, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.dataNoteText, { color: colors.muted }]}>
            {language === 'ko'
              ? '※ 관광지 데이터는 샘플 데이터입니다. 실제 서비스에서는 공공데이터 API와 연동됩니다.'
              : '※ Tourist spot data is sample data. Real service will integrate with public data APIs.'}
          </Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

function CourseCard({
  course,
  index,
  language,
  t,
  colors,
  accentColor,
  getDiffColor,
  getDiffLabel,
  onSelect,
}: {
  course: Course;
  index: number;
  language: 'ko' | 'en';
  t: any;
  colors: any;
  accentColor: string;
  getDiffColor: (diff: string) => { bg: string; text: string };
  getDiffLabel: (diff: string) => string;
  onSelect: () => void;
}) {
  const diffColors = getDiffColor(course.difficulty);
  const rankEmojis = ['🥇', '🥈', '🥉'];

  return (
    <View style={[styles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      {/* Card header */}
      <View style={[styles.cardHeader, { backgroundColor: accentColor }]}>
        <Text style={styles.rankEmoji}>{rankEmojis[index] || '📍'}</Text>
        <View style={styles.cardHeaderContent}>
          <Text style={styles.courseName}>
            {language === 'ko' ? course.name : course.nameEn}
          </Text>
          <View style={styles.cardHeaderBadges}>
            <View style={[styles.durationBadge, { backgroundColor: 'rgba(255,255,255,0.25)' }]}>
              <Text style={styles.durationText}>
                ⏱ {formatDuration(course.totalMinutes, language)}
              </Text>
            </View>
            <View style={[styles.indoorBadge, { backgroundColor: 'rgba(255,255,255,0.25)' }]}>
              <Text style={styles.indoorText}>
                {course.indoor
                  ? `🏠 ${t.course.indoor}`
                  : `🌿 ${t.course.outdoor}`}
              </Text>
            </View>
          </View>
        </View>
      </View>

      {/* Card body */}
      <View style={styles.cardBody}>
        {/* Description */}
        <Text style={[styles.description, { color: colors.foreground }]}>
          {language === 'ko' ? course.description : course.descriptionEn}
        </Text>

        {/* Info grid */}
        <View style={styles.infoGrid}>
          <View style={[styles.infoItem, { backgroundColor: diffColors.bg }]}>
            <Text style={[styles.infoLabel, { color: diffColors.text }]}>
              {t.course.difficulty}
            </Text>
            <Text style={[styles.infoValue, { color: diffColors.text }]}>
              {getDiffLabel(course.difficulty)}
            </Text>
          </View>
          <View style={[styles.infoItem, { backgroundColor: course.includesMeal ? '#F0FDF4' : colors.background }]}>
            <Text style={[styles.infoLabel, { color: colors.muted }]}>
              {language === 'ko' ? '식사' : 'Meal'}
            </Text>
            <Text style={[styles.infoValue, { color: course.includesMeal ? '#166534' : colors.muted }]}>
              {course.includesMeal
                ? (language === 'ko' ? '포함 ✓' : 'Included ✓')
                : (language === 'ko' ? '미포함' : 'Not included')}
            </Text>
          </View>
        </View>

        {/* Tags */}
        <View style={styles.tags}>
          {(language === 'ko' ? course.tags : course.tags).map((tag, i) => (
            <View key={i} style={[styles.tag, { backgroundColor: accentColor + '15', borderColor: accentColor + '40' }]}>
              <Text style={[styles.tagText, { color: accentColor }]}>{tag}</Text>
            </View>
          ))}
        </View>

        {/* Return convenience */}
        <View style={[styles.returnNote, { backgroundColor: colors.background }]}>
          <Text style={styles.returnIcon}>🔙</Text>
          <Text style={[styles.returnText, { color: colors.muted }]}>
            {language === 'ko' ? course.returnConvenience : course.returnConvenienceEn}
          </Text>
        </View>

        {/* Select button */}
        <TouchableOpacity
          style={[styles.selectBtn, { backgroundColor: accentColor }]}
          onPress={onSelect}
          activeOpacity={0.85}
        >
          <Text style={styles.selectBtnText}>{t.course.selectBtn}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  scroll: { padding: 20, paddingBottom: 40 },
  header: { marginBottom: 20 },
  backBtn: { marginBottom: 8 },
  backText: { fontSize: 15, fontWeight: '500' },
  title: { fontSize: 24, fontWeight: '800', letterSpacing: -0.5, marginBottom: 4 },
  subtitle: { fontSize: 14 },
  freeTimeReminder: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 14,
    marginBottom: 20,
  },
  freeTimeText: { fontSize: 15 },
  freeTimeBold: { fontWeight: '800' },
  card: {
    borderRadius: 16,
    borderWidth: 1,
    marginBottom: 20,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  cardHeader: {
    padding: 16,
    flexDirection: 'row',
    gap: 12,
    alignItems: 'flex-start',
  },
  rankEmoji: { fontSize: 28 },
  cardHeaderContent: { flex: 1, gap: 8 },
  courseName: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '700',
    lineHeight: 24,
  },
  cardHeaderBadges: { flexDirection: 'row', gap: 8, flexWrap: 'wrap' },
  durationBadge: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  durationText: { color: '#FFFFFF', fontSize: 13, fontWeight: '600' },
  indoorBadge: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 },
  indoorText: { color: '#FFFFFF', fontSize: 13, fontWeight: '600' },
  cardBody: { padding: 16, gap: 12 },
  description: { fontSize: 14, lineHeight: 21 },
  infoGrid: { flexDirection: 'row', gap: 10 },
  infoItem: {
    flex: 1,
    borderRadius: 10,
    padding: 12,
    alignItems: 'center',
    gap: 4,
  },
  infoLabel: { fontSize: 11 },
  infoValue: { fontSize: 14, fontWeight: '700' },
  tags: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  tag: {
    borderRadius: 10,
    borderWidth: 1,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  tagText: { fontSize: 12, fontWeight: '600' },
  returnNote: {
    borderRadius: 10,
    padding: 10,
    flexDirection: 'row',
    gap: 8,
    alignItems: 'flex-start',
  },
  returnIcon: { fontSize: 14 },
  returnText: { flex: 1, fontSize: 13, lineHeight: 19 },
  selectBtn: {
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  selectBtnText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
  empty: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 40,
    alignItems: 'center',
    gap: 12,
    marginBottom: 20,
  },
  emptyEmoji: { fontSize: 40 },
  emptyText: { fontSize: 15 },
  dataNote: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 12,
  },
  dataNoteText: { fontSize: 12, lineHeight: 18 },
});
