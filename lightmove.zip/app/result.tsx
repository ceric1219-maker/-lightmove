import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';
import { router } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useApp } from '@/lib/AppContext';
import { useColors } from '@/hooks/use-colors';
import { formatDuration, formatTime } from '@/lib/recommendEngine';
import type { Locker } from '@/lib/sampleData';

export default function ResultScreen() {
  const { t, language, timeFormat24h, recommendResult, setSelectedLocker } = useApp();
  const colors = useColors();

  if (!recommendResult) {
    return (
      <ScreenContainer>
        <View style={styles.empty}>
          <Text style={[styles.emptyText, { color: colors.muted }]}>
            {t.common.error}
          </Text>
          <TouchableOpacity onPress={() => router.back()}>
            <Text style={[styles.retryText, { color: colors.primary }]}>{t.common.retry}</Text>
          </TouchableOpacity>
        </View>
      </ScreenContainer>
    );
  }

  const { aiSummary, freeTimeCalc, recommendedLockers, luggageSize } = recommendResult;

  const sizeLabel = {
    small: t.result.lockerSize.small,
    medium: t.result.lockerSize.medium,
    large: t.result.lockerSize.large,
  }[luggageSize];

  const handleLockerSelect = (locker: Locker) => {
    setSelectedLocker(locker);
    router.push('/locker-detail' as any);
  };

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={[styles.backText, { color: colors.primary }]}>← {t.common.back}</Text>
          </TouchableOpacity>
          <Text style={[styles.title, { color: colors.foreground }]}>{t.result.title}</Text>
        </View>

        {/* AI Summary Card */}
        <View style={[styles.aiCard, { backgroundColor: colors.primary }]}>
          <View style={styles.aiHeader}>
            <Text style={styles.aiIcon}>🤖</Text>
            <Text style={styles.aiLabel}>{t.result.aiSummary}</Text>
            <View style={styles.demoTag}>
              <Text style={styles.demoTagText}>
                {language === 'ko' ? '규칙 기반 AI' : 'Rule-based AI'}
              </Text>
            </View>
          </View>
          <Text style={styles.aiText}>{aiSummary}</Text>
        </View>

        {/* Free Time Timeline */}
        <View style={[styles.timelineCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            ⏱️ {t.result.freeTime}
          </Text>
          <View style={[styles.freeTimeDisplay, { backgroundColor: colors.primary + '15' }]}>
            <Text style={[styles.freeTimeNum, { color: colors.primary }]}>
              {formatDuration(freeTimeCalc.freeTimeMin, language)}
            </Text>
            <Text style={[styles.freeTimeLabel, { color: colors.muted }]}>
              {language === 'ko' ? '자유시간' : 'Free Time'}
            </Text>
          </View>

          <View style={styles.timeline}>
            {[
              {
                icon: '🚶',
                label: language === 'ko' ? '보관함 이동' : 'To Locker',
                time: freeTimeCalc.moveToLockerMin,
              },
              {
                icon: '📦',
                label: language === 'ko' ? '짐 보관' : 'Store Luggage',
                time: freeTimeCalc.storeProcessMin,
              },
              {
                icon: '🎯',
                label: language === 'ko' ? '자유 관광' : 'Free Tour',
                time: freeTimeCalc.freeTimeMin,
                highlight: true,
              },
              {
                icon: '🔙',
                label: language === 'ko' ? '보관함 복귀' : 'Return',
                time: freeTimeCalc.returnToLockerMin,
              },
              {
                icon: '✅',
                label: language === 'ko' ? '여유 시간' : 'Buffer',
                time: freeTimeCalc.bufferMin,
              },
            ].map((item, i) => (
              <View key={i} style={styles.timelineItem}>
                <View style={[
                  styles.timelineDot,
                  { backgroundColor: item.highlight ? colors.primary : colors.border },
                ]} />
                <Text style={styles.timelineIcon}>{item.icon}</Text>
                <Text style={[
                  styles.timelineLabel,
                  { color: item.highlight ? colors.primary : colors.foreground },
                  item.highlight && { fontWeight: '700' },
                ]}>
                  {item.label}
                </Text>
                <Text style={[
                  styles.timelineTime,
                  { color: item.highlight ? colors.primary : colors.muted },
                ]}>
                  {formatDuration(item.time, language)}
                </Text>
              </View>
            ))}
          </View>

          <View style={[styles.returnAlert, { backgroundColor: '#FFF7ED', borderColor: '#F97316' }]}>
            <Text style={styles.returnAlertIcon}>⚠️</Text>
            <Text style={[styles.returnAlertText, { color: '#C2410C' }]}>
              {language === 'ko'
                ? `${formatTime(freeTimeCalc.suggestedReturnTime, timeFormat24h)}까지 복귀 시작 권장`
                : `Suggested return by ${formatTime(freeTimeCalc.suggestedReturnTime, timeFormat24h)}`}
            </Text>
          </View>
        </View>

        {/* Luggage Size Info */}
        <View style={[styles.luggageInfo, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={styles.luggageIcon}>🧳</Text>
          <Text style={[styles.luggageText, { color: colors.foreground }]}>
            {language === 'ko'
              ? `${sizeLabel} 보관함 추천`
              : `${sizeLabel} locker recommended`}
          </Text>
        </View>

        {/* Recommended Lockers */}
        <Text style={[styles.sectionTitle, { color: colors.foreground, marginBottom: 12 }]}>
          📦 {t.result.lockers}
        </Text>

        {recommendedLockers.map((locker, index) => (
          <LockerCard
            key={locker.id}
            locker={locker}
            index={index}
            language={language}
            t={t}
            colors={colors}
            onSelect={() => handleLockerSelect(locker)}
          />
        ))}

        {/* View Course Button */}
        <TouchableOpacity
          style={[styles.courseBtn, { backgroundColor: '#10B981' }]}
          onPress={() => router.push('/courses' as any)}
          activeOpacity={0.85}
        >
          <Text style={styles.courseBtnText}>🗺️ {t.result.viewCourse}</Text>
        </TouchableOpacity>
      </ScrollView>
    </ScreenContainer>
  );
}

function LockerCard({
  locker,
  index,
  language,
  t,
  colors,
  onSelect,
}: {
  locker: Locker;
  index: number;
  language: string;
  t: any;
  colors: any;
  onSelect: () => void;
}) {
  const rankColors = ['#F97316', '#6366F1', '#64748B'];
  const rankLabels = ['1st', '2nd', '3rd'];
  const rankLabelsKo = ['1순위', '2순위', '3순위'];

  return (
    <View style={[styles.lockerCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      {/* Rank badge */}
      <View style={[styles.rankBadge, { backgroundColor: rankColors[index] }]}>
        <Text style={styles.rankText}>
          {language === 'ko' ? rankLabelsKo[index] : rankLabels[index]}
        </Text>
      </View>

      <View style={styles.lockerHeader}>
        <View style={styles.lockerNameRow}>
          <Text style={[styles.lockerName, { color: colors.foreground }]}>
            {language === 'ko' ? locker.name : locker.nameEn}
          </Text>
          <View style={[
            styles.availBadge,
            { backgroundColor: locker.available ? '#DCFCE7' : '#FEE2E2' },
          ]}>
            <Text style={[
              styles.availText,
              { color: locker.available ? '#166534' : '#991B1B' },
            ]}>
              {locker.available ? t.result.available : t.result.unavailable}
            </Text>
          </View>
        </View>
        <Text style={[styles.lockerLocation, { color: colors.muted }]}>
          📍 {language === 'ko' ? locker.location : locker.locationEn}
        </Text>
      </View>

      {/* Size badges */}
      <View style={styles.sizeBadges}>
        {(['small', 'medium', 'large'] as const).map((size) => (
          <View
            key={size}
            style={[
              styles.sizeBadge,
              {
                backgroundColor: locker.sizes[size] ? colors.primary + '20' : colors.border + '40',
                borderColor: locker.sizes[size] ? colors.primary : colors.border,
              },
            ]}
          >
            <Text style={[
              styles.sizeBadgeText,
              { color: locker.sizes[size] ? colors.primary : colors.muted },
            ]}>
              {t.result.lockerSize[size]}
              {locker.sizes[size] ? ' ✓' : ' ✗'}
            </Text>
          </View>
        ))}
      </View>

      {/* Info row */}
      <View style={styles.infoRow}>
        <InfoItem icon="🚶" label={`${locker.travelMinutes}분`} colors={colors} />
        <InfoItem
          icon="💰"
          label={`${locker.feePerHour.medium.toLocaleString()}원/h`}
          colors={colors}
        />
        <InfoItem
          icon={locker.returnEase === 'good' ? '⭐' : locker.returnEase === 'ok' ? '🔸' : '🔺'}
          label={
            language === 'ko'
              ? locker.returnEase === 'good' ? '복귀 우수' : locker.returnEase === 'ok' ? '복귀 양호' : '복귀 불편'
              : locker.returnEase === 'good' ? 'Return: Good' : locker.returnEase === 'ok' ? 'Return: OK' : 'Return: Poor'
          }
          colors={colors}
        />
      </View>

      {/* Reason */}
      <View style={[styles.reasonBox, { backgroundColor: colors.primary + '10' }]}>
        <Text style={[styles.reasonText, { color: colors.primary }]}>
          💡 {language === 'ko' ? locker.notes : locker.notesEn}
        </Text>
      </View>

      {/* Buttons */}
      <View style={styles.lockerBtns}>
        <TouchableOpacity
          style={[styles.lockerBtn, { backgroundColor: colors.primary }]}
          onPress={onSelect}
          activeOpacity={0.85}
        >
          <Text style={styles.lockerBtnText}>{t.result.selectLocker}</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.lockerBtnOutline, { borderColor: colors.border }]}
          onPress={onSelect}
          activeOpacity={0.85}
        >
          <Text style={[styles.lockerBtnOutlineText, { color: colors.foreground }]}>
            {t.result.viewRoute}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

function InfoItem({ icon, label, colors }: { icon: string; label: string; colors: any }) {
  return (
    <View style={infoStyles.item}>
      <Text style={infoStyles.icon}>{icon}</Text>
      <Text style={[infoStyles.label, { color: colors.muted }]}>{label}</Text>
    </View>
  );
}

const infoStyles = StyleSheet.create({
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  icon: {
    fontSize: 14,
  },
  label: {
    fontSize: 13,
  },
});

const styles = StyleSheet.create({
  scroll: {
    padding: 20,
    paddingBottom: 40,
  },
  empty: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 16,
  },
  emptyText: {
    fontSize: 16,
  },
  retryText: {
    fontSize: 16,
    fontWeight: '600',
  },
  header: {
    marginBottom: 20,
  },
  backBtn: {
    marginBottom: 8,
  },
  backText: {
    fontSize: 15,
    fontWeight: '500',
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    letterSpacing: -0.5,
  },
  aiCard: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
  },
  aiHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  aiIcon: {
    fontSize: 20,
  },
  aiLabel: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
    flex: 1,
  },
  demoTag: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 10,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  demoTagText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '600',
  },
  aiText: {
    color: 'rgba(255,255,255,0.95)',
    fontSize: 14,
    lineHeight: 22,
  },
  timelineCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 20,
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 16,
  },
  freeTimeDisplay: {
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    marginBottom: 20,
  },
  freeTimeNum: {
    fontSize: 36,
    fontWeight: '800',
    letterSpacing: -1,
  },
  freeTimeLabel: {
    fontSize: 14,
    marginTop: 2,
  },
  timeline: {
    gap: 12,
    marginBottom: 16,
  },
  timelineItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  timelineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  timelineIcon: {
    fontSize: 16,
    width: 24,
    textAlign: 'center',
  },
  timelineLabel: {
    flex: 1,
    fontSize: 14,
  },
  timelineTime: {
    fontSize: 14,
    fontWeight: '600',
  },
  returnAlert: {
    borderRadius: 10,
    borderWidth: 1,
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  returnAlertIcon: {
    fontSize: 16,
  },
  returnAlertText: {
    fontSize: 14,
    fontWeight: '600',
    flex: 1,
  },
  luggageInfo: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 20,
  },
  luggageIcon: {
    fontSize: 20,
  },
  luggageText: {
    fontSize: 14,
    fontWeight: '600',
  },
  lockerCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    marginBottom: 16,
    position: 'relative',
  },
  rankBadge: {
    position: 'absolute',
    top: -8,
    right: 16,
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 3,
  },
  rankText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '700',
  },
  lockerHeader: {
    marginBottom: 12,
    paddingTop: 4,
  },
  lockerNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
    flexWrap: 'wrap',
  },
  lockerName: {
    fontSize: 15,
    fontWeight: '700',
    flex: 1,
  },
  availBadge: {
    borderRadius: 10,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  availText: {
    fontSize: 12,
    fontWeight: '600',
  },
  lockerLocation: {
    fontSize: 13,
    lineHeight: 18,
  },
  sizeBadges: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 12,
  },
  sizeBadge: {
    borderRadius: 8,
    borderWidth: 1,
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  sizeBadgeText: {
    fontSize: 12,
    fontWeight: '600',
  },
  infoRow: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 12,
    flexWrap: 'wrap',
  },
  reasonBox: {
    borderRadius: 10,
    padding: 10,
    marginBottom: 12,
  },
  reasonText: {
    fontSize: 13,
    lineHeight: 19,
    fontWeight: '500',
  },
  lockerBtns: {
    flexDirection: 'row',
    gap: 10,
  },
  lockerBtn: {
    flex: 1,
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: 'center',
  },
  lockerBtnText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
  },
  lockerBtnOutline: {
    flex: 1,
    borderRadius: 10,
    borderWidth: 1,
    paddingVertical: 12,
    alignItems: 'center',
  },
  lockerBtnOutlineText: {
    fontSize: 14,
    fontWeight: '600',
  },
  courseBtn: {
    borderRadius: 16,
    paddingVertical: 18,
    alignItems: 'center',
    marginTop: 8,
  },
  courseBtnText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '700',
  },
});
