import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
} from 'react-native';
import { router } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useApp } from '@/lib/AppContext';
import { useColors } from '@/hooks/use-colors';
import { routes } from '@/lib/sampleData';
import type { RouteOption } from '@/lib/sampleData';

export default function RouteDetailScreen() {
  const { t, language, selectedLocker } = useApp();
  const colors = useColors();
  const [activeTab, setActiveTab] = useState<'shortest' | 'easiest'>('easiest');

  const zone = selectedLocker?.zone || 'seoul';

  const zoneRoutes = routes.filter((r) => {
    if (zone === 'seoul') return r.from.includes('서울역') || r.from.includes('Seoul');
    if (zone === 'hongik') return r.from.includes('홍대') || r.from.includes('Hongik');
    if (zone === 'myeongdong') return r.from.includes('명동') || r.from.includes('Myeongdong');
    return false;
  });

  const shortestRoute = zoneRoutes.find((r) => r.type === 'shortest');
  const easiestRoute = zoneRoutes.find((r) => r.type === 'easiest');
  const activeRoute = activeTab === 'shortest' ? shortestRoute : easiestRoute;

  const getDiffColor = (diff: string) => {
    if (diff === 'easy') return { bg: '#DCFCE7', text: '#166534' };
    if (diff === 'medium') return { bg: '#FEF9C3', text: '#854D0E' };
    return { bg: '#FEE2E2', text: '#991B1B' };
  };

  const getDiffLabel = (diff: string) => {
    if (diff === 'easy') return t.route.easy;
    if (diff === 'medium') return t.route.medium;
    return t.route.hard;
  };

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={[styles.backText, { color: colors.primary }]}>← {t.common.back}</Text>
          </TouchableOpacity>
          <Text style={[styles.title, { color: colors.foreground }]}>{t.route.title}</Text>
          {selectedLocker && (
            <Text style={[styles.subtitle, { color: colors.muted }]}>
              {language === 'ko' ? selectedLocker.location : selectedLocker.locationEn}
            </Text>
          )}
        </View>

        {/* Tab selector */}
        <View style={[styles.tabContainer, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <TouchableOpacity
            style={[
              styles.tab,
              activeTab === 'shortest' && { backgroundColor: colors.primary },
            ]}
            onPress={() => setActiveTab('shortest')}
          >
            <Text style={[
              styles.tabText,
              { color: activeTab === 'shortest' ? '#FFFFFF' : colors.muted },
            ]}>
              ⚡ {t.route.shortest}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.tab,
              activeTab === 'easiest' && { backgroundColor: '#10B981' },
            ]}
            onPress={() => setActiveTab('easiest')}
          >
            <Text style={[
              styles.tabText,
              { color: activeTab === 'easiest' ? '#FFFFFF' : colors.muted },
            ]}>
              🧳 {t.route.easiest}
            </Text>
          </TouchableOpacity>
        </View>

        {activeRoute ? (
          <>
            {/* Route summary */}
            <View style={[styles.summaryCard, { backgroundColor: activeTab === 'easiest' ? '#F0FDF4' : '#EFF6FF', borderColor: activeTab === 'easiest' ? '#10B981' : colors.primary }]}>
              <View style={styles.summaryRow}>
                <View style={styles.summaryItem}>
                  <Text style={[styles.summaryNum, { color: activeTab === 'easiest' ? '#10B981' : colors.primary }]}>
                    {activeRoute.durationMinutes}
                  </Text>
                  <Text style={[styles.summaryLabel, { color: colors.muted }]}>
                    {t.route.minutes}
                  </Text>
                </View>
                <View style={[styles.divider, { backgroundColor: colors.border }]} />
                <View style={styles.summaryItem}>
                  <View style={[
                    styles.diffBadge,
                    { backgroundColor: getDiffColor(activeRoute.difficulty).bg },
                  ]}>
                    <Text style={[
                      styles.diffText,
                      { color: getDiffColor(activeRoute.difficulty).text },
                    ]}>
                      {getDiffLabel(activeRoute.difficulty)}
                    </Text>
                  </View>
                  <Text style={[styles.summaryLabel, { color: colors.muted }]}>
                    {t.route.difficulty}
                  </Text>
                </View>
                <View style={[styles.divider, { backgroundColor: colors.border }]} />
                <View style={styles.summaryItem}>
                  <Text style={[styles.summaryNum, { color: colors.foreground }]}>
                    {activeRoute.transfers}
                  </Text>
                  <Text style={[styles.summaryLabel, { color: colors.muted }]}>
                    {t.route.transfers}
                  </Text>
                </View>
              </View>

              {/* Features */}
              <View style={styles.features}>
                {activeRoute.stairsAvoided && (
                  <View style={[styles.featureBadge, { backgroundColor: '#DCFCE7' }]}>
                    <Text style={[styles.featureText, { color: '#166534' }]}>
                      ✓ {t.route.stairsAvoided}
                    </Text>
                  </View>
                )}
                {activeRoute.elevatorAvailable && (
                  <View style={[styles.featureBadge, { backgroundColor: '#EFF6FF' }]}>
                    <Text style={[styles.featureText, { color: '#1D4ED8' }]}>
                      🛗 {t.route.elevator} {t.route.yes}
                    </Text>
                  </View>
                )}
                {activeRoute.escalatorAvailable && (
                  <View style={[styles.featureBadge, { backgroundColor: '#FEF9C3' }]}>
                    <Text style={[styles.featureText, { color: '#854D0E' }]}>
                      🔼 {t.route.escalator} {t.route.yes}
                    </Text>
                  </View>
                )}
              </View>
            </View>

            {/* Route steps */}
            <View style={[styles.stepsCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
              <Text style={[styles.stepsTitle, { color: colors.foreground }]}>
                {language === 'ko' ? '경로 안내' : 'Route Guide'}
              </Text>
              {activeRoute.steps.map((step, i) => (
                <View key={i} style={styles.stepRow}>
                  <View style={styles.stepLeft}>
                    <View style={[
                      styles.stepIconBg,
                      {
                        backgroundColor:
                          step.type === 'elevator' ? '#EFF6FF'
                          : step.type === 'escalator' ? '#FEF9C3'
                          : step.type === 'subway' ? '#F0FDF4'
                          : colors.primary + '15',
                      },
                    ]}>
                      <Text style={styles.stepIcon}>{step.icon}</Text>
                    </View>
                    {i < activeRoute.steps.length - 1 && (
                      <View style={[styles.stepLine, { backgroundColor: colors.border }]} />
                    )}
                  </View>
                  <View style={styles.stepContent}>
                    <Text style={[styles.stepDesc, { color: colors.foreground }]}>
                      {language === 'ko' ? step.description : step.descriptionEn}
                    </Text>
                    <Text style={[styles.stepTime, { color: colors.muted }]}>
                      {step.durationMinutes}{t.route.minutes}
                    </Text>
                  </View>
                </View>
              ))}
            </View>

            {/* Tip */}
            <View style={[styles.tipCard, { backgroundColor: '#FFF7ED', borderColor: '#F97316' }]}>
              <Text style={styles.tipIcon}>💡</Text>
              <Text style={[styles.tipText, { color: '#C2410C' }]}>
                {activeTab === 'easiest'
                  ? (language === 'ko'
                    ? '짐 끌기 편한 경로입니다. 엘리베이터와 에스컬레이터를 우선 이용하세요.'
                    : 'This is the luggage-friendly route. Prioritize elevators and escalators.')
                  : (language === 'ko'
                    ? '최단 경로이지만 계단이 포함될 수 있습니다. 짐이 무거운 경우 편한 경로를 이용하세요.'
                    : 'This is the shortest route but may include stairs. Use the luggage-friendly route for heavy luggage.')}
              </Text>
            </View>
          </>
        ) : (
          <View style={[styles.noRoute, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.noRouteText, { color: colors.muted }]}>
              {language === 'ko' ? '경로 정보가 없습니다' : 'No route information available'}
            </Text>
          </View>
        )}

        {/* Back to result */}
        <TouchableOpacity
          style={[styles.backToResult, { backgroundColor: colors.primary }]}
          onPress={() => router.push('/courses' as any)}
          activeOpacity={0.85}
        >
          <Text style={styles.backToResultText}>
            {language === 'ko' ? '반나절 코스 보기 →' : 'View Half-Day Plans →'}
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  scroll: { padding: 20, paddingBottom: 40 },
  header: { marginBottom: 20 },
  backBtn: { marginBottom: 8 },
  backText: { fontSize: 15, fontWeight: '500' },
  title: { fontSize: 24, fontWeight: '800', letterSpacing: -0.5, marginBottom: 4 },
  subtitle: { fontSize: 14 },
  tabContainer: {
    flexDirection: 'row',
    borderRadius: 14,
    borderWidth: 1,
    padding: 4,
    marginBottom: 20,
  },
  tab: {
    flex: 1,
    borderRadius: 10,
    paddingVertical: 12,
    alignItems: 'center',
  },
  tabText: { fontSize: 14, fontWeight: '600' },
  summaryCard: {
    borderRadius: 16,
    borderWidth: 1.5,
    padding: 20,
    marginBottom: 16,
  },
  summaryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    marginBottom: 16,
  },
  summaryItem: { alignItems: 'center', gap: 4 },
  summaryNum: { fontSize: 28, fontWeight: '800' },
  summaryLabel: { fontSize: 12 },
  divider: { width: 1, height: 40 },
  diffBadge: { borderRadius: 8, paddingHorizontal: 10, paddingVertical: 5 },
  diffText: { fontSize: 14, fontWeight: '700' },
  features: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  featureBadge: { borderRadius: 10, paddingHorizontal: 10, paddingVertical: 5 },
  featureText: { fontSize: 13, fontWeight: '600' },
  stepsCard: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    marginBottom: 16,
  },
  stepsTitle: { fontSize: 15, fontWeight: '700', marginBottom: 16 },
  stepRow: { flexDirection: 'row', gap: 12, marginBottom: 4 },
  stepLeft: { alignItems: 'center', width: 44 },
  stepIconBg: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepIcon: { fontSize: 20 },
  stepLine: { width: 2, flex: 1, marginTop: 4, marginBottom: 4, minHeight: 16 },
  stepContent: { flex: 1, paddingTop: 10, paddingBottom: 16 },
  stepDesc: { fontSize: 14, lineHeight: 20, marginBottom: 2 },
  stepTime: { fontSize: 12 },
  tipCard: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 14,
    flexDirection: 'row',
    gap: 10,
    marginBottom: 20,
  },
  tipIcon: { fontSize: 18 },
  tipText: { flex: 1, fontSize: 13, lineHeight: 20 },
  noRoute: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 40,
    alignItems: 'center',
    marginBottom: 20,
  },
  noRouteText: { fontSize: 15 },
  backToResult: {
    borderRadius: 16,
    paddingVertical: 18,
    alignItems: 'center',
  },
  backToResultText: { color: '#FFFFFF', fontSize: 17, fontWeight: '700' },
});
