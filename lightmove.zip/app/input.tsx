import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Platform,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useApp } from '@/lib/AppContext';
import { useColors } from '@/hooks/use-colors';
import { getRecommendations } from '@/lib/recommendEngine';
import type { UserInput } from '@/lib/recommendEngine';

export default function InputScreen() {
  const { t, language, setUserInput, setRecommendResult } = useApp();
  const colors = useColors();
  const params = useLocalSearchParams<{ situation: string }>();
  const situation = (params.situation || 'before-checkin') as 'before-checkin' | 'after-checkout';

  const [location, setLocation] = useState('');
  const [scheduleHour, setScheduleHour] = useState(15);
  const [scheduleMin, setScheduleMin] = useState(0);
  const [selectedLuggage, setSelectedLuggage] = useState<string[]>([]);
  const [selectedMove, setSelectedMove] = useState<string>('');
  const [selectedTour, setSelectedTour] = useState<string[]>([]);

  const locations = t.input.locations;
  const luggageTypes = t.input.luggageTypes;
  const movePrefers = t.input.movePrefers;
  const tourPrefers = t.input.tourPrefers;

  const toggleLuggage = (item: string) => {
    setSelectedLuggage((prev) =>
      prev.includes(item) ? prev.filter((x) => x !== item) : [...prev, item],
    );
  };

  const toggleTour = (item: string) => {
    setSelectedTour((prev) =>
      prev.includes(item) ? prev.filter((x) => x !== item) : [...prev, item],
    );
  };

  const handleSubmit = () => {
    if (!location) {
      return;
    }

    const nextScheduleTime = new Date();
    nextScheduleTime.setHours(scheduleHour, scheduleMin, 0, 0);
    if (nextScheduleTime <= new Date()) {
      nextScheduleTime.setDate(nextScheduleTime.getDate() + 1);
    }

    const input: UserInput = {
      situation,
      location,
      nextScheduleTime,
      luggageTypes: selectedLuggage.length > 0 ? selectedLuggage : [luggageTypes[0]],
      movePrefers: selectedMove ? [selectedMove] : [],
      tourPrefers: selectedTour,
      language,
    };

    setUserInput(input);
    const result = getRecommendations(input);
    setRecommendResult(result);
    router.push('/result' as any);
  };

  const hours = Array.from({ length: 24 }, (_, i) => i);
  const mins = [0, 15, 30, 45];

  return (
    <ScreenContainer>
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={[styles.backText, { color: colors.primary }]}>← {t.common.back}</Text>
          </TouchableOpacity>
          <View style={[styles.situationBadge, { backgroundColor: situation === 'before-checkin' ? '#EFF6FF' : '#F0FDF4' }]}>
            <Text style={[styles.situationText, { color: situation === 'before-checkin' ? '#2563EB' : '#10B981' }]}>
              {situation === 'before-checkin' ? t.situation.checkinBefore : t.situation.checkoutAfter}
            </Text>
          </View>
        </View>

        <Text style={[styles.title, { color: colors.foreground }]}>{t.input.title}</Text>
        <Text style={[styles.subtitle, { color: colors.muted }]}>{t.input.subtitle}</Text>

        {/* Step indicator */}
        <View style={styles.steps}>
          {['위치', '시간', '짐', '이동', '관광'].map((s, i) => (
            <View key={i} style={styles.stepItem}>
              <View style={[styles.stepDot, { backgroundColor: colors.primary }]}>
                <Text style={styles.stepNum}>{i + 1}</Text>
              </View>
            </View>
          ))}
        </View>

        {/* 1. 위치 선택 */}
        <SectionCard title={`1. ${t.input.location}`} colors={colors}>
          <View style={styles.chipRow}>
            {locations.map((loc) => (
              <TouchableOpacity
                key={loc}
                style={[
                  styles.chip,
                  {
                    backgroundColor: location === loc ? colors.primary : colors.surface,
                    borderColor: location === loc ? colors.primary : colors.border,
                  },
                ]}
                onPress={() => setLocation(loc)}
              >
                <Text
                  style={[
                    styles.chipText,
                    { color: location === loc ? '#FFFFFF' : colors.foreground },
                  ]}
                >
                  {loc}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
          {!location && (
            <Text style={[styles.hint, { color: colors.error }]}>
              {language === 'ko' ? '위치를 선택해주세요' : 'Please select a location'}
            </Text>
          )}
        </SectionCard>

        {/* 2. 다음 일정 시간 */}
        <SectionCard title={`2. ${t.input.nextScheduleLabel}`} colors={colors}>
          <View style={styles.timePicker}>
            <View style={styles.timeGroup}>
              <Text style={[styles.timeLabel, { color: colors.muted }]}>
                {language === 'ko' ? '시' : 'Hour'}
              </Text>
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.timeScroll}
              >
                {hours.map((h) => (
                  <TouchableOpacity
                    key={h}
                    style={[
                      styles.timeChip,
                      {
                        backgroundColor: scheduleHour === h ? colors.primary : colors.surface,
                        borderColor: scheduleHour === h ? colors.primary : colors.border,
                      },
                    ]}
                    onPress={() => setScheduleHour(h)}
                  >
                    <Text
                      style={[
                        styles.timeChipText,
                        { color: scheduleHour === h ? '#FFFFFF' : colors.foreground },
                      ]}
                    >
                      {h.toString().padStart(2, '0')}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>
            <View style={styles.timeGroup}>
              <Text style={[styles.timeLabel, { color: colors.muted }]}>
                {language === 'ko' ? '분' : 'Min'}
              </Text>
              <View style={styles.minRow}>
                {mins.map((m) => (
                  <TouchableOpacity
                    key={m}
                    style={[
                      styles.chip,
                      {
                        backgroundColor: scheduleMin === m ? colors.primary : colors.surface,
                        borderColor: scheduleMin === m ? colors.primary : colors.border,
                      },
                    ]}
                    onPress={() => setScheduleMin(m)}
                  >
                    <Text
                      style={[
                        styles.chipText,
                        { color: scheduleMin === m ? '#FFFFFF' : colors.foreground },
                      ]}
                    >
                      {m.toString().padStart(2, '0')}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </View>
          <View style={[styles.timeDisplay, { backgroundColor: colors.primary + '15' }]}>
            <Text style={[styles.timeDisplayText, { color: colors.primary }]}>
              {language === 'ko' ? '선택된 시간: ' : 'Selected: '}
              {scheduleHour.toString().padStart(2, '0')}:{scheduleMin.toString().padStart(2, '0')}
            </Text>
          </View>
        </SectionCard>

        {/* 3. 짐 종류 */}
        <SectionCard title={`3. ${t.input.luggage}`} colors={colors} hint={t.input.luggageHint}>
          <View style={styles.chipRow}>
            {luggageTypes.map((item) => (
              <TouchableOpacity
                key={item}
                style={[
                  styles.chip,
                  {
                    backgroundColor: selectedLuggage.includes(item) ? colors.primary : colors.surface,
                    borderColor: selectedLuggage.includes(item) ? colors.primary : colors.border,
                  },
                ]}
                onPress={() => toggleLuggage(item)}
              >
                <Text
                  style={[
                    styles.chipText,
                    { color: selectedLuggage.includes(item) ? '#FFFFFF' : colors.foreground },
                  ]}
                >
                  {item}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </SectionCard>

        {/* 4. 이동 선호 */}
        <SectionCard title={`4. ${t.input.movePrefer}`} colors={colors}>
          <View style={styles.chipRow}>
            {movePrefers.map((item) => (
              <TouchableOpacity
                key={item}
                style={[
                  styles.chip,
                  {
                    backgroundColor: selectedMove === item ? '#0EA5E9' : colors.surface,
                    borderColor: selectedMove === item ? '#0EA5E9' : colors.border,
                  },
                ]}
                onPress={() => setSelectedMove(selectedMove === item ? '' : item)}
              >
                <Text
                  style={[
                    styles.chipText,
                    { color: selectedMove === item ? '#FFFFFF' : colors.foreground },
                  ]}
                >
                  {item}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </SectionCard>

        {/* 5. 관광 선호 */}
        <SectionCard title={`5. ${t.input.tourPrefer}`} colors={colors} hint={t.input.luggageHint}>
          <View style={styles.chipRow}>
            {tourPrefers.map((item) => (
              <TouchableOpacity
                key={item}
                style={[
                  styles.chip,
                  {
                    backgroundColor: selectedTour.includes(item) ? '#F97316' : colors.surface,
                    borderColor: selectedTour.includes(item) ? '#F97316' : colors.border,
                  },
                ]}
                onPress={() => toggleTour(item)}
              >
                <Text
                  style={[
                    styles.chipText,
                    { color: selectedTour.includes(item) ? '#FFFFFF' : colors.foreground },
                  ]}
                >
                  {item}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </SectionCard>

        {/* Submit */}
        <TouchableOpacity
          style={[
            styles.submitBtn,
            { backgroundColor: location ? colors.primary : colors.muted },
          ]}
          onPress={handleSubmit}
          disabled={!location}
          activeOpacity={0.85}
        >
          <Text style={styles.submitText}>{t.input.submit}</Text>
        </TouchableOpacity>
      </ScrollView>
    </ScreenContainer>
  );
}

function SectionCard({
  title,
  hint,
  colors,
  children,
}: {
  title: string;
  hint?: string;
  colors: any;
  children: React.ReactNode;
}) {
  return (
    <View style={[sectionStyles.card, { backgroundColor: colors.surface, borderColor: colors.border }]}>
      <View style={sectionStyles.titleRow}>
        <Text style={[sectionStyles.title, { color: colors.foreground }]}>{title}</Text>
        {hint && <Text style={[sectionStyles.hint, { color: colors.muted }]}>{hint}</Text>}
      </View>
      {children}
    </View>
  );
}

const sectionStyles = StyleSheet.create({
  card: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    marginBottom: 16,
  },
  titleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  title: {
    fontSize: 15,
    fontWeight: '700',
  },
  hint: {
    fontSize: 12,
  },
});

const styles = StyleSheet.create({
  scroll: {
    padding: 20,
    paddingBottom: 40,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  backBtn: {
    paddingVertical: 4,
  },
  backText: {
    fontSize: 15,
    fontWeight: '500',
  },
  situationBadge: {
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 6,
  },
  situationText: {
    fontSize: 13,
    fontWeight: '600',
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    letterSpacing: -0.5,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    marginBottom: 20,
  },
  steps: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
    marginBottom: 20,
  },
  stepItem: {
    alignItems: 'center',
  },
  stepDot: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepNum: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '700',
  },
  chipRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  chip: {
    borderRadius: 20,
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  chipText: {
    fontSize: 14,
    fontWeight: '500',
  },
  hint: {
    fontSize: 12,
    marginTop: 8,
  },
  timePicker: {
    gap: 12,
  },
  timeGroup: {
    gap: 8,
  },
  timeLabel: {
    fontSize: 13,
    fontWeight: '600',
  },
  timeScroll: {
    gap: 8,
    paddingRight: 8,
  },
  timeChip: {
    borderRadius: 10,
    borderWidth: 1,
    paddingHorizontal: 12,
    paddingVertical: 8,
    minWidth: 44,
    alignItems: 'center',
  },
  timeChipText: {
    fontSize: 14,
    fontWeight: '500',
  },
  minRow: {
    flexDirection: 'row',
    gap: 8,
  },
  timeDisplay: {
    borderRadius: 10,
    padding: 10,
    marginTop: 12,
    alignItems: 'center',
  },
  timeDisplayText: {
    fontSize: 15,
    fontWeight: '700',
  },
  submitBtn: {
    borderRadius: 16,
    paddingVertical: 18,
    alignItems: 'center',
    marginTop: 8,
  },
  submitText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '700',
  },
});
