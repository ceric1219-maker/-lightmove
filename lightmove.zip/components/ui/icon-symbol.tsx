// Fallback for using MaterialIcons on Android and web.

import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconSymbolName = keyof typeof MAPPING;

/**
 * SF Symbols to Material Icons mappings for Light Move app
 */
const MAPPING = {
  // Navigation
  "house.fill": "home",
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "chevron.left": "chevron-left",
  "xmark": "close",
  "xmark.circle.fill": "cancel",

  // App specific
  "archivebox.fill": "inventory",
  "map.fill": "map",
  "gearshape.fill": "settings",
  "location.fill": "location-on",
  "clock.fill": "access-time",
  "suitcase.fill": "luggage",
  "figure.walk": "directions-walk",
  "star.fill": "star",
  "checkmark.circle.fill": "check-circle",
  "exclamationmark.circle.fill": "error",
  "info.circle.fill": "info",
  "arrow.right": "arrow-forward",
  "arrow.left": "arrow-back",
  "arrow.up": "arrow-upward",
  "arrow.down": "arrow-downward",
  "magnifyingglass": "search",
  "bell.fill": "notifications",
  "person.fill": "person",
  "globe": "language",
  "calendar": "calendar-today",
  "tag.fill": "local-offer",
  "heart.fill": "favorite",
  "square.and.arrow.up": "share",
  "rotate.left": "refresh",
  "bolt.fill": "bolt",
  "leaf.fill": "eco",
  "fork.knife": "restaurant",
  "camera.fill": "camera-alt",
  "photo.fill": "photo",
  "cart.fill": "shopping-cart",
  "building.2.fill": "business",
  "train.side.front.car": "train",
  "tram.fill": "tram",
  "elevator": "elevator",
  "stairs": "stairs",
  "figure.stand": "accessibility",
  "timer": "timer",
  "checkmark": "check",
  "minus": "remove",
  "plus": "add",
  "circle.fill": "circle",
  "circle": "radio-button-unchecked",
  "square.fill": "square",
  "rectangle.fill": "rectangle",
  "wifi": "wifi",
  "battery.100": "battery-full",
} as const;

/**
 * An icon component that uses native SF Symbols on iOS, and Material Icons on Android and web.
 */
export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}
