/** @type {const} */
const themeColors = {
  primary: { light: '#2563EB', dark: '#3B82F6' },
  secondary: { light: '#0EA5E9', dark: '#38BDF8' },
  accent: { light: '#F97316', dark: '#FB923C' },
  background: { light: '#F8FAFC', dark: '#0F172A' },
  surface: { light: '#FFFFFF', dark: '#1E293B' },
  foreground: { light: '#1E293B', dark: '#F1F5F9' },
  muted: { light: '#64748B', dark: '#94A3B8' },
  border: { light: '#E2E8F0', dark: '#334155' },
  success: { light: '#10B981', dark: '#34D399' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };
