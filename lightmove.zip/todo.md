# 라이트무브 (Light Move) — TODO

## 브랜딩 & 설정
- [x] 앱 로고 생성 (generate)
- [x] 테마 색상 설정 (theme.config.js)
- [x] app.config.ts 앱 이름/로고 업데이트
- [x] icon-symbol.tsx 아이콘 매핑 추가

## 데이터 & 로직
- [x] 보관함 샘플 데이터 (서울역/홍대/명동 권역)
- [x] 관광지 샘플 데이터
- [x] 이동 경로 샘플 데이터
- [x] 자유시간 계산 로직
- [x] AI 추천 엔진 (규칙 기반)
- [x] 다국어 i18n 시스템 (한/영)
- [x] 앱 상태 관리 (Context)

## 화면 구현
- [x] 온보딩 화면 (Onboarding)
- [x] 상황 선택 화면 (SituationSelect)
- [x] 정보 입력 화면 (InputForm)
- [x] 추천 결과 화면 (RecommendResult)
- [x] 보관함 상세 화면 (LockerDetail)
- [x] 이동 경로 화면 (RouteDetail)
- [x] 반나절 코스 추천 화면 (CourseRecommend)
- [x] 요약 화면 (Summary)
- [x] 설정 화면 (Settings)
- [x] 보관함 목록 탭 화면
- [x] 코스 탐색 탭 화면

## 네비게이션
- [x] 탭 네비게이션 (홈/보관함/코스/설정)
- [x] 스택 네비게이션 (플로우 화면들)

## README
- [x] README.md 작성 (앱 개요, 기술, 데이터 구분, 설치, 향후 개선)
